package emergencia;

import util.LoggerUtil;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * ⚠️ MODO DE EMERGÊNCIA/Teste
 * Esta classe permite autenticação via ficheiro Login.txt.
 * Apenas usada em situações de teste ou quando o acesso à base de dados está indisponível.
 * 
 * Formato esperado no ficheiro Login.txt:
 *     nomeUtilizador;senhaSimples
 */


public class Login {
	 private static final String VERMELHO = "\u001B[31m";

    public static boolean autenticar(String utilizador, String senha) {
    	File ficheiro = new File("login.txt");

        try (Scanner leitor = new Scanner(ficheiro)) {
            while (leitor.hasNextLine()) {
                String linha = leitor.nextLine();
                String[] partes = linha.split(";");

                if (partes.length == 2) {
                    String user = partes[0].trim();
                    String pass = partes[1].trim();

                    if (utilizador.equals(user) && senha.equals(pass)) {
                    	LoggerUtil.logAcesso("Login bem-sucedido para o utilizador: " + utilizador);
                        return true;
                    }
                }
            }
            // Se passar por todas as linhas e não autenticar:
            LoggerUtil.logNegado("Tentativa de login falhada para o utilizador: " + utilizador);
            
        } catch (FileNotFoundException e) {
            System.out.println(VERMELHO + "❌ Ficheiro de login não encontrado.");
            LoggerUtil.logErro("Ficheiro login.txt não encontrado: " + e.getMessage());
        }

        return false;
    }
    
    public static void testarFicheiroLogin() {
        try {
            File ficheiro = new File("login.txt");
            Scanner leitor = new Scanner(ficheiro);
            leitor.close();
        } catch (FileNotFoundException e) {
            System.out.println(VERMELHO + "❌ ERRO: Ficheiro de login não encontrado!");
        }
    }
}


