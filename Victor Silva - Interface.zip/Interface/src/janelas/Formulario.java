package janelas;
 
import java.awt.Image;
import java.io.File;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
 
public class Formulario {
 
    public static void main(String[] args) {
 
        JFrame frame = new JFrame("Formulário Boas Vindas");
        frame.setSize(600, 900);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
 
        // JLabel para imagem (foto de perfil)
        JLabel imagemLabel = new JLabel();
        imagemLabel.setBounds(400, 20, 150, 250);  // lado direito, topo
        frame.add(imagemLabel);
 
        JLabel nome = new JLabel("Nome");
        nome.setBounds(20, 20, 80, 25);
        frame.add(nome);
 
        JTextField campoNome = new JTextField();
        campoNome.setBounds(100, 20, 200, 30);
        frame.add(campoNome);
 
        JLabel mail = new JLabel("Email");
        mail.setBounds(20, 60, 80, 25);
        frame.add(mail);
 
        JTextField campoMail = new JTextField();
        campoMail.setBounds(100, 60, 200, 30);
        campoMail.setInputVerifier(new EmailVerifier());
        frame.add(campoMail);
 
        JLabel password = new JLabel("Password");
        password.setBounds(20, 100, 80, 25);
        frame.add(password);
 
        JPasswordField campoSenha = new JPasswordField();
        campoSenha.setBounds(100, 100, 200, 30);
        frame.add(campoSenha);
 
        JLabel idade = new JLabel("Idade");
        idade.setBounds(20, 140, 80, 25);
        frame.add(idade);
 
        JSpinner campoIdade = new JSpinner(new SpinnerNumberModel(18, 10, 30, 1));
        campoIdade.setBounds(100, 140, 60, 30);
        frame.add(campoIdade);
 
        JCheckBox check = new JCheckBox("Aceito os termos");
        check.setBounds(20, 180, 200, 25);
        frame.add(check);
 
        JRadioButton op1 = new JRadioButton("Opção 1");
        JRadioButton op2 = new JRadioButton("Opção 2");
        op1.setBounds(20, 220, 100, 25);
        op2.setBounds(120, 220, 100, 25);
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(op1);
        grupo.add(op2);
        frame.add(op1);
        frame.add(op2);
 
        JLabel combo = new JLabel("Escolha 1 item");
        combo.setBounds(20, 260, 130, 25);
        frame.add(combo);
 
        String[] opcoes = { "Item 1", "Item 2", "Item 3" };
        JComboBox<String> comboBox = new JComboBox<>(opcoes);
        comboBox.setBounds(150, 260, 150, 25);
        frame.add(comboBox);
 
        JTextArea area = new JTextArea("Escreva qualquer coisa aqui");
        JScrollPane scrollTexto = new JScrollPane(area);
        scrollTexto.setBounds(20, 300, 330, 60);
        frame.add(scrollTexto);
 
        JSeparator separador = new JSeparator();
        separador.setBounds(20, 380, 330, 10);
        frame.add(separador);
 
        JLabel labelLista = new JLabel("Selecione suas cores favoritas:");
        labelLista.setBounds(20, 380, 250, 25);
        frame.add(labelLista);
 
        String[] cores = { "Vermelho", "Azul", "Verde", "Amarelo", "Preto" };
        JList<String> listaCores = new JList<>(cores);
        listaCores.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollLista = new JScrollPane(listaCores);
        scrollLista.setBounds(20, 410, 150, 80);
        frame.add(scrollLista);
 
        String[] colunas = { "Nome", "Idade" };
        String[][] dados = {
            { "João", "25" },
            { "Carlos", "50" },
            { "Sandra", "45" },
            { "Filipa", "25" },
        };
 
        JTable grelha = new JTable(dados, colunas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JScrollPane scrollTabela = new JScrollPane(grelha);
        scrollTabela.setBounds(20, 500, 560, 200); // aumentei largura para caber mais colunas
        frame.add(scrollTabela);
 
        JMenuBar menuBar = new JMenuBar();
        JMenu menuArquivo = new JMenu("Arquivo");
        JMenu menuConta = new JMenu("Conta");
        JMenu menuSair = new JMenu("Sair");
 
        JMenuItem itemAbrirImagem = new JMenuItem("Abrir imagem");
        JMenuItem itemAbrirTexto = new JMenuItem("Abrir arquivo texto");
        JMenuItem itemCriar = new JMenuItem("Criar");
        JMenuItem itemConsultar = new JMenuItem("Consultar");
        JMenuItem itemTransferir = new JMenuItem("Transferir");
        JMenuItem itemSair = new JMenuItem("Sair do programa");
 
        menuArquivo.add(itemAbrirImagem);
        menuArquivo.add(itemAbrirTexto);
        menuArquivo.add(itemCriar);
        menuConta.add(itemConsultar);
        menuConta.add(itemTransferir);
        menuSair.add(itemSair);
 
        menuBar.add(menuArquivo);
        menuBar.add(menuConta);
        menuBar.add(menuSair);
 
        frame.setJMenuBar(menuBar);
 
        // Botão de sair
        itemSair.addActionListener(e -> {
            int resposta = JOptionPane.showConfirmDialog(frame, "Deseja realmente sair?", "Sair",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resposta == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });
 
        // Abrir imagem e redimensionar para caber na label
        itemAbrirImagem.addActionListener(e -> {
            JFileChooser seletor = new JFileChooser();
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("Imagens (JPG, PNG, GIF)", "jpg", "jpeg", "png", "gif");
            seletor.setFileFilter(filtro);
 
            int resultado = seletor.showOpenDialog(frame);
            if (resultado == JFileChooser.APPROVE_OPTION) {
                File imagem = seletor.getSelectedFile();
                ImageIcon icon = new ImageIcon(imagem.getAbsolutePath());
 
                // Redimensionar para o tamanho da label
                Image img = icon.getImage();
                Image imgRedimensionada = img.getScaledInstance(imagemLabel.getWidth(), imagemLabel.getHeight(), Image.SCALE_SMOOTH);
                imagemLabel.setIcon(new ImageIcon(imgRedimensionada));
            }
        });
 
        // Abrir arquivo texto e carregar na tabela
        itemAbrirTexto.addActionListener(e -> {
            JFileChooser seletor = new JFileChooser();
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("Arquivos de texto", "txt", "csv");
            seletor.setFileFilter(filtro);
 
            int resultado = seletor.showOpenDialog(frame);
            if (resultado == JFileChooser.APPROVE_OPTION) {
                File arquivo = seletor.getSelectedFile();
                carregarArquivoNaTabela(arquivo, grelha);
            }
        });
 
        // Botão enviar
        JButton botao = new JButton("Enviar");
        botao.setBounds(100, 720, 120, 30);
        frame.add(botao);
 
        botao.addActionListener(e -> {
            String nome1 = campoNome.getText().trim();
            String email1 = campoMail.getText().trim();
            String senha1 = new String(campoSenha.getPassword());
            int idade1 = (int) campoIdade.getValue();
 
            if (!check.isSelected()) {
                JOptionPane.showMessageDialog(frame, "Você deve aceitar os termos.", "Aviso", JOptionPane.WARNING_MESSAGE);
            } else if (nome1.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Por favor, insira um nome.", "Erro", JOptionPane.WARNING_MESSAGE);
            } else if (senha1.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Por favor, insira uma senha.", "Erro", JOptionPane.WARNING_MESSAGE);
            } else {
                String opcaoSelecionada = (String) comboBox.getSelectedItem();
                String radioSelecionado = op1.isSelected() ? "Opção 1" : op2.isSelected() ? "Opção 2" : "Nenhuma";
                Object[] coresSelecionadas = listaCores.getSelectedValuesList().toArray();
 
                JOptionPane.showMessageDialog(frame,
                        "Olá, " + nome1 + "!\n" +
                                "Email: " + email1 + "\n" +
                                "Idade: " + idade1 + "\n" +
                                "Item: " + opcaoSelecionada + "\n" +
                                "Opção: " + radioSelecionado + "\n" +
                                "Cores: " +
                                (coresSelecionadas.length > 0
                                        ? String.join(", ", listaCores.getSelectedValuesList())
                                        : "Nenhuma"));
            }
        });
 
        frame.setVisible(true);
    }
 
    // Método para carregar arquivo texto separado por ; e atualizar JTable
    public static void carregarArquivoNaTabela(File arquivo, JTable tabela) {
        try {
            java.util.List<String> linhas = java.nio.file.Files.readAllLines(arquivo.toPath());
 
            if (linhas.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Arquivo vazio!");
                return;
            }
 
            // Pega o cabeçalho da tabela na primeira linha
            String[] colunas = linhas.get(0).split(";");
 
            // Prepara os dados das linhas restantes
            String[][] dados = new String[linhas.size() - 1][colunas.length];
            for (int i = 1; i < linhas.size(); i++) {
                String[] partes = linhas.get(i).split(";");
                for (int j = 0; j < partes.length; j++) {
                    dados[i - 1][j] = partes[j];
                }
            }
 
            // Atualiza o modelo da tabela
            DefaultTableModel model = new DefaultTableModel(dados, colunas) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tabela.setModel(model);
 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao ler arquivo: " + e.getMessage());
        }
    }
 
    static class EmailVerifier extends InputVerifier {
        private final Pattern emailRegex = Pattern.compile("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
 
        @Override
        public boolean verify(JComponent input) {
            String email = ((JTextField) input).getText().trim();
            if (email.isEmpty() || emailRegex.matcher(email).matches()) {
                return true;
            } else {
                JOptionPane.showMessageDialog(input, "Email inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
    }
}