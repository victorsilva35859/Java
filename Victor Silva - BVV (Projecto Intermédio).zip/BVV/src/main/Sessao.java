package main;

public class Sessao {
    public static String nivelAtual = "";
    public static String utilizadorAtual = "";
    public static int idUtilizador;
}
