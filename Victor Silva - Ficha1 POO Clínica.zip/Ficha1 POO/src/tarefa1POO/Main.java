package tarefa1POO;

import java.util.ArrayList;
import java.util.List;

public class Main {

    // Constantes de cores ANSI
    public static final String RESET = "\u001B[0m";
    public static final String AZUL = "\u001B[34m";
    public static final String VERDE = "\u001B[32m";
    public static final String AMARELO = "\u001B[33m";
    public static final String CYAN = "\u001B[36m";
    public static final String LARANJA = "\u001B[38;5;208m";
    public static final String VERMELHO = "\u001B[31m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String PURPLE = "\u001B[35m";

    // Função para devolver a cor com base no IMC
    public static String corIMC(double imc) {
        if (imc < 18.5) return AZUL;
        else if (imc < 25) return VERDE;
        else if (imc < 30) return AMARELO;
        else if (imc < 35) return LARANJA;
        else if (imc < 40) return VERMELHO;
        else return VERMELHO;
    }

    public static void main(String[] args) {
        System.out.println("\u001B[36m\uD83D\uDCCB Fórmula do IMC: IMC = Peso (kg) / (Altura (m) × Altura (m))\u001B[0m\n");

        System.out.println("\u001B[35mClassificação do IMC segundo a OMS:\u001B[0m");
        System.out.println("\u001B[34m\uD83D\uDFE6 Abaixo do peso: IMC < 18.5\u001B[0m");
        System.out.println("\u001B[32m\uD83D\uDFE9 Peso normal: 18.5 ≤ IMC ≤ 24.9\u001B[0m");
        System.out.println("\u001B[33m\uD83D\uDFE8 Sobrepeso: 25 ≤ IMC ≤ 29.9\u001B[0m");
        System.out.println("\u001B[38;5;208m\uD83D\uDFE7 Obesidade grau 1: 30 ≤ IMC ≤ 34.9\u001B[0m");
        System.out.println("\u001B[31m\uD83D\uDFE5 Obesidade grau 2: 35 ≤ IMC ≤ 39.9\u001B[0m");
        System.out.println("\u001B[31m\uD83D\uDFE5 Obesidade grau 3: IMC ≥ 40\u001B[0m");
        System.out.println("-".repeat(50));
        System.out.println("-".repeat(50) + "\n");

        Pessoa p1 = new Paciente("Victor Silva", 48, 1.80, 70.0);
        Pessoa p2 = new Paciente("Bia Laginha", 16, 1.62, 75.0);


        p1.apresentarDados();
        System.out.println("-".repeat(50));
        System.out.println("-".repeat(50) + "\n");
        p2.apresentarDados();
        
     // 🔽 POLIMORFISMO 🔽
     System.out.println("-".repeat(50));
     System.out.println("-".repeat(50));
     System.out.println("\n" + Main.MAGENTA + "🧬 Demonstração de Polimorfismo com Pessoa, Paciente e Médico" + Main.RESET);


     // Lista polimórfica
     List<Pessoa> pessoas = new ArrayList<>();

     // Adicionando pacientes
     pessoas.add(new Paciente("João Coelho", 33, 1.70, 80.0));
     pessoas.add(new Paciente("Ana Marta", 28, 1.58, 152.0));

     // Adicionando médico
     pessoas.add(new Medico("Dra. Sandra Luz", 45, "M12345", "Nutricionista"));

     // Percorrer a lista e chamar apresentarDados() (polimorfismo!)
     for (Pessoa p : pessoas) {
    	    if (p instanceof Paciente) {
    	        System.out.println(AZUL + "\n👤 Apresentação do Paciente:\n" + RESET);
    	    } else if (p instanceof Medico) {
    	        System.out.println(AZUL + "\n👨‍⚕️ Apresentação do Médico:\n" + RESET);
    	    } else {
    	        System.out.println(AZUL + "\n👤 Apresentação da Pessoa:\n" + RESET);
    	    }

    	    p.apresentarDados();
    	    System.out.println("-".repeat(50));
    	    System.out.println("-".repeat(50));
    	}
     
     System.out.println(Main.MAGENTA + "\n🔍 Teste do uso da Interface Avaliacao:" + RESET);

     // Criar instância de médico que implementa Avaliacao
     Medico drCarlos = new Medico("Dr. Carlos Almeida", 50, "M98765", "Clínico Geral");

     // Criar pacientes para avaliação
     Paciente paciente1 = new Paciente("Luis Faria", 35, 1.75, 95.0);
     Paciente paciente2 = new Paciente("Sara Lima", 29, 1.65, 54.0);

     // Avaliar os pacientes usando a interface Avaliacao
     drCarlos.avaliarPaciente(paciente1);
     System.out.println("-".repeat(50));
     drCarlos.avaliarPaciente(paciente2);
    }
     
}



