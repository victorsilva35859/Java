package ex2;

import java.io.*;
import java.net.*;

public class Server {

    public static void main(String[] args) {
        int porta = 12345;

        try (ServerSocket serverSocket = new ServerSocket(porta)) {
            System.out.println("Servidor a aguardar ligações");

            Socket cliente = serverSocket.accept();
            System.out.println("Cliente ligado: " + cliente.getInetAddress());

            BufferedReader input = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            PrintWriter output = new PrintWriter(cliente.getOutputStream(), true); // auto-flush

            String mensagem = input.readLine();
            System.out.println("Mensagem recebida: " + mensagem);

            output.println("Recebido com sucesso, obrigado pela tua mensagem!");

            cliente.close();

        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}

