package Ex1;

import java.io.*;
import java.net.*;

public class TCPClient {

	public static void main(String[] args) {
		
		String host="localhost";
		int porta=5000;
		
		try(Socket socket=new Socket(host, porta)) {
			OutputStream output=socket.getOutputStream();
			PrintWriter escreve=new PrintWriter(output, true);
			escreve.println("Olá servidor!!!");
			System.out.println("Mensagem enviada!!!");
			socket.close();
				
			}catch(IOException e) {
				System.out.println("Erro: " + e.getMessage());
			

	}

	}
	
}
