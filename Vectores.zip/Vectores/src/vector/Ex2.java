package vector;

import java.util.Scanner;

	public class Ex2 {
		public static void main(String[] args) {
			Scanner ent= new Scanner(System.in);
	int x=0;
	
	System.out.println("Qual o número de elementos");
	x=ent.nextInt();
	
	int[] nota=new int[x];
	
	
	for(int i=0; i<x; i++) {
		System.out.println("Intorduza o valor");
		nota[i]=ent.nextInt();
	}
	
	for(int i=0; i<x; i++) {
		System.out.println("Valor armazenado - " + nota[i]);
	}
  }
}