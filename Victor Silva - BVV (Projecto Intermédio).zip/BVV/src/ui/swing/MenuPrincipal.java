package ui.swing;

import javax.swing.*;
//import javax.swing.ImageIcon;

import main.Sessao;
import service.ContaService;
import service.UserService;
import java.awt.*;
import java.sql.Connection;
import ui.swing.MenuContas;
import ui.swing.MenuUtilizadores;

@SuppressWarnings({ "serial", "unused" })
public class MenuPrincipal extends JFrame {
	private UserService userService;
	private final Connection conn;



	public MenuPrincipal(String nome, String nivel, UserService userService, Connection conn) {
        super("Menu Principal BVV");
        this.userService = userService;
        this.conn = conn;

        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        

        JLabel lblBoasVindas = new JLabel(
        	    "<html><div style='text-align: center; color:#003366; font-size:16px;'>"
       // RGB em valores HEX (R- Valor HEX 0 e Decimal 0;		G- Valor HEX 33 e Decimal 51;		B- Valor HEX 66 e Decimal 102)	
        	    + "🏦 <b>Bem-vindo, " + nome + " (" + nivel.toUpperCase() + ")!</b>"
        	    + "</div></html>"
        	);
        	lblBoasVindas.setHorizontalAlignment(SwingConstants.CENTER);


        	JButton btnGestaoUtilizadores = new JButton("Gestão de Utilizadores");
        	// ESTILO ELEGANTE
        	ImageIcon userIcon = new ImageIcon("src/resources/UsersManager.png");
        	Image imagemUsers = userIcon.getImage().getScaledInstance(35, 30, Image.SCALE_SMOOTH);
        	btnGestaoUtilizadores.setIcon(new ImageIcon(imagemUsers));
        	btnGestaoUtilizadores.setBackground(new Color(230, 240, 255)); // Azul claro (RGB - Red, Green, Blue) valores de 0 a 255
        	btnGestaoUtilizadores.setForeground(Color.BLACK); // Cor do texto: preto
        	btnGestaoUtilizadores.setFont(new Font("SansSerif", Font.BOLD, 13)); // PLAIN (sem negrito) e BOLD (Negrito)
        	btnGestaoUtilizadores.setBorder(BorderFactory.createCompoundBorder(
        	    BorderFactory.createLineBorder(new Color(100, 150, 200)),    // Contorno leve
        	    BorderFactory.createEmptyBorder(10, 20, 10, 20)              // Espaço interno
        	));
        JButton btnGestaoContas = new JButton("Gestão de Contas Bancárias");
     // ESTILO ELEGANTE
        ImageIcon contasIcon = new ImageIcon("src/resources/CartãoMB.png");
        Image imagemContas = contasIcon.getImage().getScaledInstance(30, 25, Image.SCALE_SMOOTH);
        btnGestaoContas.setIcon(new ImageIcon(imagemContas));
    	btnGestaoContas.setBackground(new Color(230, 240, 255)); // Azul claro
    	btnGestaoContas.setForeground(Color.BLACK); // Cor do texto: preto
    	btnGestaoContas.setFont(new Font("SansSerif", Font.BOLD, 13)); // PLAIN (sem negrito) e BOLD (Negrito)
    	btnGestaoContas.setBorder(BorderFactory.createCompoundBorder(
    	    BorderFactory.createLineBorder(new Color(100, 150, 200)),    // Contorno leve
    	    BorderFactory.createEmptyBorder(10, 20, 10, 20)              // Espaço interno
    	));
        JButton btnTerminarSessao = new JButton("Terminar Sessão");
     // ESTILO ELEGANTE
        ImageIcon cadeadoIcon = new ImageIcon("src/resources/Cadeado.png");
        Image imagemCadeado = cadeadoIcon.getImage().getScaledInstance(35, 28, Image.SCALE_SMOOTH);
        btnTerminarSessao.setIcon(new ImageIcon(imagemCadeado));
    	btnTerminarSessao.setBackground(new Color(230, 240, 255)); // Azul claro
    	btnTerminarSessao.setForeground(Color.BLACK); // Cor do texto: preto
    	btnTerminarSessao.setFont(new Font("SansSerif", Font.BOLD, 13)); // PLAIN (sem negrito) e BOLD (Negrito)
    	btnTerminarSessao.setBorder(BorderFactory.createCompoundBorder(
    	    BorderFactory.createLineBorder(new Color(100, 150, 200)),    // Contorno leve
    	    BorderFactory.createEmptyBorder(10, 20, 10, 20)              // Espaço interno
    	));
        JButton btnSair = new JButton("Sair");
     // ESTILO ELEGANTE
        ImageIcon exitIcon = new ImageIcon("src/resources/ExitRed.png");
        Image imagemExit = exitIcon.getImage().getScaledInstance(30, 25, Image.SCALE_SMOOTH);
        btnSair.setIcon(new ImageIcon(imagemExit));
    	btnSair.setBackground(new Color(230, 240, 255)); // Azul claro
    	btnSair.setForeground(Color.RED); // Cor do texto: preto
    	btnSair.setFont(new Font("SansSerif", Font.BOLD, 13)); // PLAIN (sem negrito) e BOLD (Negrito)
    	btnSair.setBorder(BorderFactory.createCompoundBorder(
    	    BorderFactory.createLineBorder(new Color(100, 150, 200)),    // Contorno leve
    	    BorderFactory.createEmptyBorder(10, 20, 10, 20)              // Espaço interno
    	));

        btnGestaoUtilizadores.setVisible("ADMIN".equalsIgnoreCase(nivel));

        setLayout(new GridLayout(5, 1, 10, 10));
        add(lblBoasVindas);
        add(btnGestaoUtilizadores);
        add(btnGestaoContas);
        add(btnTerminarSessao);
        add(btnSair);

        // Listeners para os botões
        btnGestaoUtilizadores.addActionListener(e -> {
            new MenuUtilizadores(nome, nivel, userService, conn).setVisible(true);
            dispose(); // Fecha esta janela
        });
        btnGestaoContas.addActionListener(e -> {
        	MenuContas menuContas = new MenuContas(new ContaService(conn), this);
        	menuContas.setVisible(true);
        	this.setVisible(false); // Esconde o Menu Principal
        });
        btnSair.addActionListener(e -> {
            // 🧼 Limpa os dados da sessão
            Sessao.utilizadorAtual = "";
            Sessao.nivelAtual = "";
            Sessao.idUtilizador = 0;

            // ✅ Mensagem de debug
            System.out.println("\u001B[32m✔ Sessão terminada com sucesso!\u001B[0m");

            // Encerra a aplicação
            System.exit(0);
        });   
        btnTerminarSessao.addActionListener(e -> {
            // 🧼 Limpa a sessão
            Sessao.utilizadorAtual = "";
            Sessao.nivelAtual = "";
            Sessao.idUtilizador = 0;

            // ✅ Mensagem de debug
            System.out.println("\u001B[33m🔒 Sessão encerrada, voltando ao login...\u001B[0m");

            // Volta à JanelaLogin
            new JanelaLogin(userService, conn).setVisible(true);

            // Fecha o MenuPrincipal
            dispose();
        });
    }
}
