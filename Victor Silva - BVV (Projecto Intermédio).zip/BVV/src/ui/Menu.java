package ui;

import java.sql.SQLException;
import java.util.Scanner;

import main.Sessao;
import service.UserService;
import service.ContaService;

public class Menu {

    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String AZUL = "\u001B[34m";
    private static final String AMARELO = "\u001B[33m";
    private static final String CIANO_CLARO = "\u001B[96m";
    private static final String BRANCO = "\u001B[37m";
    private static final String LARANJA = "\u001B[38;5;208m";
    private static final String CIANO_TURQ = "\u001B[36m";
    //private static final String MAGENTA = "\u001B[35m";

    private final UserService userService;
    private final ContaService contaService;
    private final Scanner scanner;

    public Menu(UserService userService, ContaService contaService) {
        this.userService = userService;
        this.contaService = contaService;
        this.scanner = new Scanner(System.in);
    }

    // MENU PRINCIPAL
    public void menuPrincipal() {
        while (true) {
            // Boas-vindas estilizadas
            System.out.println(AZUL + "\n***************************************" + RESET);
            System.out.println(CIANO_CLARO + "        Bem-vindo ao Banco BVV!" + RESET);
            System.out.println(AZUL + "***************************************\n\n" + RESET);

            // Menu Principal com cores nas opções
            System.out.println(BRANCO + "=========== MENU PRINCIPAL (" + Sessao.nivelAtual + ") ===========" + RESET);
            if ("ADMIN".equalsIgnoreCase(Sessao.nivelAtual)) {
                System.out.println(AZUL + "1" + " - Gestão de Utilizadores");
            }
            System.out.println(LARANJA + "2" + " - Gestão de Contas Bancárias");
            System.out.println(VERMELHO + "0" + " - Sair");
            System.out.print(AMARELO + "Escolha uma opção: " + RESET);

            int opcao = 0;
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println(VERMELHO + "Entrada inválida !! Digite um número." + RESET);
                continue;
            }

            switch (opcao) {
                case 1 -> {
                    if ("ADMIN".equalsIgnoreCase(Sessao.nivelAtual)) {
                        userMenu();
                    } else {
                        System.out.println(VERMELHO + "Acesso negado! Só o administrador pode aceder a esta opção." + RESET);
                    }
                }
                case 2 -> contaMenu();
                case 0 -> {
                    System.out.println(VERDE + "\nA sair... Obrigado!\n" + RESET);
                    return;
                }
                default -> System.out.println(VERMELHO + "Opção inválida !! Tente novamente." + RESET);
            }
        }
    }

    // SUBMENU DE UTILIZADORES
    public void userMenu() {
    	if (!"ADMIN".equalsIgnoreCase(Sessao.nivelAtual)) {
            System.out.println(VERMELHO + "Acesso negado! Só o administrador pode aceder a este menu !!" + RESET);
            return;
        }
        while (true) {
            System.out.println(AZUL + "\n--- MENU DE UTILIZADORES ---" + RESET);
            System.out.println(VERDE + "1" + " - Criar utilizador");
            System.out.println(CIANO_CLARO + "2" + " - Listar utilizadores");
            System.out.println(LARANJA + "3" + " - Atualizar utilizador");
            System.out.println(VERMELHO + "4" + " - Excluir utilizador");
            System.out.println(BRANCO + "0" + " - Voltar");
            System.out.print(AMARELO + "Escolha uma opção: " + RESET);

            int opcao = 0;
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println(VERMELHO + "Entrada inválida !! Digite um número." + RESET);
                continue;
            }

            switch (opcao) {
                case 1 -> criarUtilizador();
                case 2 -> listarUtilizador();
                case 3 -> atualizarUtilizador();
                case 4 -> excluirUtilizador();
                case 0 -> { return; }
                default -> System.out.println(VERMELHO + "Opção inválida !! Tente novamente." + RESET);
            }
        }
    }

    private void criarUtilizador() {
        System.out.print(CIANO_CLARO + "Nome: " + RESET);
        String nome = scanner.nextLine();
        System.out.print(CIANO_CLARO + "Senha: " + RESET);
        String senha = scanner.nextLine();
        System.out.print(CIANO_CLARO + "Nível: " + RESET);
        String nivel = scanner.nextLine().trim();
        try {
            userService.criarUtilizador(nome, senha, nivel);
            System.out.println(VERDE + "Utilizador criado com sucesso!" + RESET);
        } catch(SQLException e) {
            System.out.println(VERMELHO + "Erro ao criar o utilizador: " + e.getMessage() + RESET);
        }
    }

    private void listarUtilizador() {
        try {
            userService.listarUtilizador();
        } catch(SQLException e) {
            System.out.println(VERMELHO + "Erro ao listar os utilizadores: " + e.getMessage() + RESET);
        }
    }

    private void atualizarUtilizador() {
        System.out.print(CIANO_CLARO + "ID do utilizador a ser atualizado: " + RESET);
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print(CIANO_CLARO + "Novo nome: " + RESET);
        String nome = scanner.nextLine();
        System.out.print(CIANO_CLARO + "Nova senha: " + RESET);
        String senha = scanner.nextLine();
        System.out.print(CIANO_CLARO + "Novo nível: " + RESET);
        String nivel = scanner.nextLine().trim();
        try {
            userService.atualizarUtilizador(id, nome, senha, nivel);
            System.out.println(VERDE + "Utilizador atualizado com sucesso!" + RESET);
        } catch(SQLException e) {
            System.out.println(VERMELHO + "Erro ao atualizar o utilizador: " + e.getMessage() + RESET);
        }
    }

    private void excluirUtilizador() {
        System.out.print(CIANO_CLARO + "ID do utilizador a ser excluído: " + RESET);
        int id = Integer.parseInt(scanner.nextLine());
        try {
            userService.excluirUtilizador(id);
            System.out.println(VERDE + "Utilizador excluído com sucesso!" + RESET);
        } catch(SQLException e) {
            System.out.println(VERMELHO + "Erro ao excluir o utilizador: " + e.getMessage() + RESET);
        }
    }

    // SUBMENU DE CONTAS
    public void contaMenu() {
        while (true) {
            System.out.println(LARANJA + "\n--- MENU DE CONTAS ---" + RESET);
            System.out.println(VERDE + "1" + " - Criar conta");
            System.out.println(BRANCO + "2" + " - Listar contas");
            System.out.println(VERMELHO + "3" + " - Apagar conta");
            System.out.println(VERDE + "4" + " - Depositar");
            System.out.println(AMARELO + "5" + " - Levantar");
            System.out.println(LARANJA + "6" + " - Transferir");
            System.out.println(CIANO_CLARO + "7" + " - Consultar conta");
            System.out.println(CIANO_TURQ + "8 - Listar Contas + Utilizadores (VIEW)" + RESET);
            System.out.println(BRANCO + "0" + " - Voltar");
            System.out.print(AMARELO + "Escolha uma opção: " + RESET);

            int opcao = 0;
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println(VERMELHO + "Entrada inválida !! Digite um número." + RESET);
                continue;
            }

            switch (opcao) {
                case 1 -> criarConta();
                case 2 -> listarContas();
                case 3 -> apagarConta();
                case 4 -> depositar();
                case 5 -> levantar();
                case 6 -> transferir();
                case 7 -> consultarConta();
                case 8 -> listarContasUtilizadoresView();
                case 0 -> { return; }
                default -> System.out.println(VERMELHO + "Opção inválida !! Tente novamente." + RESET);
            }
        }
    }

    private void criarConta() {
        try {
            System.out.print(CIANO_CLARO + "Titular: " + RESET);
            String titular = scanner.nextLine();

            System.out.print(CIANO_CLARO + "Número da conta: " + RESET);
            int numConta = Integer.parseInt(scanner.nextLine());

            System.out.print(CIANO_CLARO + "Saldo inicial: " + RESET);
            double saldo = Double.parseDouble(scanner.nextLine());

            System.out.print(CIANO_CLARO + "Tipo de conta (Ordem/Poupanca): " + RESET);
            String tipoConta = scanner.nextLine();

            Double limite = null, taxa = null;
            if ("Ordem".equalsIgnoreCase(tipoConta)) {
                System.out.print(CIANO_CLARO + "Limite: " + RESET);
                limite = Double.parseDouble(scanner.nextLine());
            } else if ("Poupanca".equalsIgnoreCase(tipoConta)) {
                System.out.print(CIANO_CLARO + "Taxa: " + RESET);
                taxa = Double.parseDouble(scanner.nextLine());
            }

            contaService.criarConta(titular, numConta, saldo, tipoConta, limite, taxa);
            System.out.println(VERDE + "Conta criada com sucesso!" + RESET);

        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro ao criar conta: " + e.getMessage() + RESET);
        }
    }

    private void listarContas() {
        try {
            contaService.listarContas();
        } catch (SQLException e) {
            System.out.println(VERMELHO + "Erro ao listar contas: " + e.getMessage() + RESET);
        }
    }

    private void apagarConta() {
        try {
            System.out.print(CIANO_CLARO + "Número da conta a apagar: " + RESET);
            int numConta = Integer.parseInt(scanner.nextLine());
            boolean sucesso = contaService.apagarConta(numConta);
            if (sucesso) {
                System.out.println(VERDE + "Conta removida com sucesso!" + RESET);
            } else {
                System.out.println(VERMELHO + "Conta não encontrada !!!!" + RESET);
            }
        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro ao apagar conta: " + e.getMessage() + RESET);
        }
    }

    private void depositar() {
        try {
            System.out.print(CIANO_CLARO + "Número da conta: " + RESET);
            int numConta = Integer.parseInt(scanner.nextLine());
            System.out.print(CIANO_CLARO + "Valor a depositar: " + RESET);
            double valor = Double.parseDouble(scanner.nextLine());
            boolean sucesso = contaService.depositar(numConta, valor);
            if (sucesso) {
                System.out.println(VERDE + "Depósito realizado com sucesso!" + RESET);
            } else {
                System.out.println(VERMELHO + "Conta não encontrada !!!!" + RESET);
            }
        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro ao depositar: " + e.getMessage() + RESET);
        }
    }

    private void levantar() {
        try {
            System.out.print(CIANO_CLARO + "Número da conta: " + RESET);
            int numConta = Integer.parseInt(scanner.nextLine());

            System.out.print(CIANO_CLARO + "Valor a levantar: " + RESET);
            double valor = Double.parseDouble(scanner.nextLine());

            int resultado = contaService.levantar(numConta, valor);

            switch (resultado) {
                case 0 -> System.out.println(VERMELHO + "❌ Conta não encontrada !!!!" + RESET);
                case 1 -> System.out.println(LARANJA + "⚠️ Saldo insuficiente para o levantamento !!" + RESET);
                case 2 -> System.out.println(VERDE + "✔️ Levantamento efetuado com sucesso!" + RESET);
                default -> System.out.println(VERMELHO + "❌ Erro inesperado no levantamento !!!!" + RESET);
            }
        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro ao levantar: " + e.getMessage() + RESET);
        }
    }

    private void transferir() {
        try {
            System.out.print(CIANO_CLARO + "Conta de origem: " + RESET);
            int origem = Integer.parseInt(scanner.nextLine());
            System.out.print(CIANO_CLARO + "Conta de destino: " + RESET);
            int destino = Integer.parseInt(scanner.nextLine());
            System.out.print(CIANO_CLARO + "Valor a transferir: " + RESET);
            double valor = Double.parseDouble(scanner.nextLine());
            boolean sucesso = contaService.transferir(origem, destino, valor);
            if (sucesso) {
                System.out.println(VERDE + "Transferência realizada com sucesso!" + RESET);
            } else {
                System.out.println(LARANJA + "Transferência não realizada." + RESET);
            }
        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro na transferência: " + e.getMessage() + RESET);
        }
    }

    private void consultarConta() {
        try {
            System.out.print(CIANO_CLARO + "Número da conta a consultar: " + RESET);
            int numConta = Integer.parseInt(scanner.nextLine());
            contaService.consultarConta(numConta);
        } catch (Exception e) {
            System.out.println(VERMELHO + "Erro ao consultar conta: " + e.getMessage() + RESET);
        }
    }
    
    private void listarContasUtilizadoresView() {
        try {
            contaService.listarContasUtilizadores();
        } catch (SQLException e) {
            System.out.println(VERMELHO + "Erro ao listar a VIEW: " + e.getMessage() + RESET);
        }
    }
}
