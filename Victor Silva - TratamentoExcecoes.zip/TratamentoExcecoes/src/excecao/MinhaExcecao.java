package excecao;

public class MinhaExcecao extends Exception{

	public MinhaExcecao(String mensagem) {
		super(mensagem);				
	}
	
	public MinhaExcecao(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}

}
