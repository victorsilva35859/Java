package erros;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) /*throws ArithmeticException*/ {
		
		Scanner ent = null;
		 
        try {
            ent = new Scanner(System.in);
            System.out.println("Introduza um valor");
            int num1 = ent.nextInt();
            System.out.println("Introduza segundo valor");
            int num2 = ent.nextInt();
            double res = num1 / num2;
            System.out.println(res);
 
        } catch (ArithmeticException e) {
            System.out.println("Erro de cálculo " + e.getMessage());
        } finally {
            if (ent != null) {
                ent.close();
                System.out.println("Scanner fechado!");
            }
        }
    }
}
