package erros;

public class Ex4 {

	public static void main(String[] args) {
		
		String numero="abc";
		
		try {
			int valor=Integer.parseInt(numero);
		}catch (NumberFormatException e) {
			System.out.println("Formato de número inválido!");
		}

	}

}
