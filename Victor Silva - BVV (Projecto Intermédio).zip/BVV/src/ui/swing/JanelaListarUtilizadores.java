package ui.swing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import service.UserService;
import java.util.List;

@SuppressWarnings("serial")
public class JanelaListarUtilizadores extends JFrame {
    private final UserService userService;
    private JTable tabela;

    @SuppressWarnings("unused")
	public JanelaListarUtilizadores(UserService userService) {
        super("Lista de Utilizadores");
        this.userService = userService;
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Modelo da tabela
        DefaultTableModel model = new DefaultTableModel(new Object[]{"ID", "Nome", "Nível"}, 0);
        tabela = new JTable(model);
        JScrollPane scroll = new JScrollPane(tabela);

        // Botão Voltar
        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.addActionListener(e -> dispose());

        // Layout
        add(scroll, "Center");
        add(btnVoltar, "South");

        // Preencher a tabela com os dados da base de dados
        preencherTabela(model);
    }

    // Método para buscar e mostrar utilizadores
    private void preencherTabela(DefaultTableModel model) {
        try {
            List<Object[]> utilizadores = userService.listarTodos(); // (ainda vais criar este método no UserService)
            for (Object[] row : utilizadores) {
                model.addRow(row);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao listar utilizadores: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
