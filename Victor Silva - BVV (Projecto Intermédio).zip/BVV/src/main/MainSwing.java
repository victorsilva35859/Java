package main;

import service.UserService;
import ui.swing.JanelaLogin;
import database.DataBaseConnection;
import java.sql.Connection;

public class MainSwing {
    @SuppressWarnings("resource")
	public static void main(String[] args) {
        try {
            // 1. Cria o objeto DataBaseConnection
            DataBaseConnection dbConn = new DataBaseConnection();

            // 2. Obtém a Connection a partir do objeto
            Connection conn = dbConn.getConnection();

            // 3. Cria o UserService com a conexão
            UserService userService = new UserService(conn);

            // 4. Abre a janela Swing
            new JanelaLogin(userService, conn).setVisible(true);;


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


