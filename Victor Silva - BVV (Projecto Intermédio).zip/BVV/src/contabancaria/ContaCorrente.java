package contabancaria;

public class ContaCorrente extends Contabancaria {

    private double limite;

    public ContaCorrente(String titular, int numConta, double saldo, TipoConta tipoConta, double limite)
            throws DadosInvalidosException {
        super(titular, numConta, saldo, tipoConta);
        this.limite = limite;
    }

    @Override
    public boolean levantar(double valor) {
        if (valor > 0 && valor <= getSaldo() + limite) {
            setSaldo(getSaldo() - valor);
            System.out.printf(AMARELO + "💸 Foi levantado %.2f€, ficou com um saldo de %.2f€\n" + RESET, valor, getSaldo());
            return true;
        } else {
            System.out.printf(VERMELHO + "❌ Tentativa de levantamento de %.2f€ inválida! Saldo e limite insuficiente (%.2f€).\n" + RESET, valor, getSaldo());
            return false;
        }
    }

    @Override
    public void depositar(double valor) {
        if (valor > 0) {
            setSaldo(getSaldo() + valor);
            System.out.printf(VERDE + "💵 Foi depositado %.2f€, ficou com um saldo de %.2f€\n" + RESET, valor, getSaldo());
        } else {
            System.out.println(VERMELHO + "❌ O valor do depósito tem que ser positivo." + RESET);
        }
    }

    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String AZUL = "\u001B[34m";
    private static final String AMARELO = "\u001B[33m";

    @Override
    public void mostrarDados() {
        System.out.println(AZUL + "Titular: " + RESET + getTitular());
        System.out.println(AZUL + "Número da Conta: " + RESET + getNumConta());
        System.out.println(AZUL + "Saldo: " + RESET + String.format("%.2f€", getSaldo() + limite));
        System.out.println(AZUL + "Tipo de Conta: " + RESET + getTipoConta());
    }
}
