package excecao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ErroBD {
    private static Connection conn;

    public static void main(String[] args) {
        try {
            conn = DriverManager.getConnection(
                "jdbc:sqlserver://localhost:1433;databaseName=BVV;user=Victor(sa);password=Cinel2025;encrypt=true;trustServerCertificate=true");
            
            executaQuery();

        } catch (SQLException e) {
            System.out.println("Erro ao executar query: " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                    System.out.println("Ligação fechada");
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a BD: " + e.getMessage());
            }
        }
    }

    public static void executaQuery() throws SQLException {
        Statement stmt = conn.createStatement();
        stmt.execute("SELECT * FROM tabela");
    }
}