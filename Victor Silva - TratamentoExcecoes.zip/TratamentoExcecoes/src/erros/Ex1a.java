package erros;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;

public class Ex1a {
    public static void main(String[] args) {
        File ficheiro = new File("meutexto.txt");
        BufferedReader leitor = null;

        try {
            leitor = new BufferedReader(new FileReader(ficheiro));
            String linha;
            while ((linha = leitor.readLine()) != null) {
                System.out.println(linha);
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler o ficheiro: " + e.getMessage());
        } finally {
            if (leitor != null) {
                try {
                    leitor.close();
                    System.out.println("Ficheiro fechado com sucesso!");
                } catch (IOException e) {
                    System.out.println("Erro ao fechar o ficheiro: " + e.getMessage());
                }
            }
        }
    }
}
