package Ex1;

import java.io.*;
import java.net.*;

public class TCPServer {

    public static void main(String[] args) {
        int porta = 5000;
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(porta);
            System.out.println("Servidor à escuta na porta 5000...");

            // Loop infinito para aceitar vários clientes
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Novo cliente ligado: " + socket.getInetAddress());

                // Ler mensagem do cliente
                InputStream input = socket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                String mensagem = reader.readLine();

                System.out.println("Mensagem recebida: " + mensagem);

                // Fechar socket do cliente (apenas este)
                socket.close();
            }

        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            try {
                if (serverSocket != null && !serverSocket.isClosed()) {
                    serverSocket.close(); // só fecha o servidor se necessário
                }
            } catch (IOException e) {
                System.out.println("Erro ao fechar o servidor: " + e.getMessage());
            }
        }
    }
}




/*
 * ServerSocket finalServerSocket = serverSocket;
 * Runtime.getRuntime().addShutdownHook(new Thread(() -> { try { if
 * (finalServerSocket != null && !finalServerSocket.isClosed()) {
 * finalServerSocket.close();
 * System.out.println("Socket fechado com sucesso via shutdown hook!"); } }
 * catch (IOException e) { System.out.println("Erro ao fechar via hook: " +
 * e.getMessage()); } }));
 */