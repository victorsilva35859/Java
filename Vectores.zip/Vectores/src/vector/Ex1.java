package vector;

public class Ex1 {

	public static void main(String[] args) {
	//tipo[] nome_array = new tipo[numero_elementos];
	 
	//tipo[] nome_array = {val1, val2, val3, ......., valx}

	double[] nota= new double[5];
	
	nota[0]=10.5;
	nota[1]=12.4;
	nota[2]=14.4;
	nota[3]=16.4;
	nota[4]=15.4;
	
	System.out.println(nota[4]);
	}
	
}