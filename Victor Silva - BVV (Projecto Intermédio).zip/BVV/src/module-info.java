module BVV {
	requires java.sql;
	requires java.desktop;
}