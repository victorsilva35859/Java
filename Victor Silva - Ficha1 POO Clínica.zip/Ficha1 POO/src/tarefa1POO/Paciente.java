package tarefa1POO;

public class Paciente extends Pessoa {
    private double altura;  // em metros
    private double peso;    // em quilogramas

    // Cores ANSI
    private static final String RESET = "\u001B[0m";
    private static final String BLUE = "\u001B[34m";
    private static final String CYAN = "\u001B[36m";
    private static final String YELLOW = "\u001B[33m";
    private static final String GREEN = "\u001B[32m";
    private static final String RED = "\u001B[31m";

    public Paciente(String nome, int idade, double altura, double peso) {
        super(nome, idade);
        this.altura = altura;
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public double getPeso() {
        return peso;
    }

    public double calcularIMC() {
        return peso / (altura * altura);
    }

    public boolean maiorDeIdade() {
        return idade >= 18;
    }

    public String interpretarIMC() {
        double imc = calcularIMC();
        if (imc < 18.5) return "Abaixo do peso";
        else if (imc < 25) return "Peso normal";
        else if (imc < 30) return "Sobrepeso";
        else if (imc < 35) return "Obesidade grau 1";
        else if (imc < 40) return "Obesidade grau 2";
        else return "Obesidade grau 3";
    }

    @Override
    public void apresentarDados() {
        System.out.println(BLUE + "👤 Nome do Paciente: " + RESET + nome);
        System.out.println(CYAN + "📅 Idade: " + RESET + idade);
        System.out.printf(YELLOW + "📏 Altura: " + RESET + "%.2fm\n", altura);
        System.out.printf(YELLOW + "⚖️ Peso: " + RESET + "%.2fkg\n", peso);

        double imc = calcularIMC();
        String classificacao = interpretarIMC();
        System.out.printf("🧮 IMC: %.2f (", imc);
        System.out.print(Main.corIMC(imc) + classificacao + RESET);
        System.out.println(")");


        System.out.println(maiorDeIdade()
                ? GREEN + "✅ Maior de idade" + RESET
                : RED + "🚫 Menor de idade" + RESET);
    }
}
