package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import main.Sessao;

public class ContaService {
    private final Connection conn;
    
    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String AZUL = "\u001B[34m";
    private static final String AMARELO = "\u001B[33m";
    private static final String CIANO_CLARO = "\u001B[96m";
    private static final String BRANCO = "\u001B[37m";
    private static final String LARANJA = "\u001B[38;5;208m";
    
    public ContaService(Connection conn) {
        this.conn = conn;
    }
    
    public ResultSet obterTodasContas() throws SQLException {
        String sql = "SELECT idConta, titular, saldo FROM contas";
        PreparedStatement stmt = conn.prepareStatement(sql);
        return stmt.executeQuery();
    }

    // Criar nova conta (de Ordem ou Poupança)
    public void criarConta(String titular, int numConta, double saldo, String tipoConta, Double limite, Double taxa) throws SQLException {
        String sql = "INSERT INTO contas (titular, numConta, saldo, tipoConta, limite, taxa, idUtilizador) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        System.out.println("🔍 DEBUG CRIAR CONTA -> ID utilizador atual: " + Sessao.idUtilizador);


        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, titular);
            stmt.setInt(2, numConta);
            stmt.setDouble(3, saldo);
            stmt.setString(4, tipoConta);

            if (limite != null) {
                stmt.setDouble(5, limite);
            } else {
                stmt.setNull(5, java.sql.Types.DECIMAL);
            }
            if (taxa != null) {
                stmt.setDouble(6, taxa);
            } else {
                stmt.setNull(6, java.sql.Types.DECIMAL);
            }

            stmt.setInt(7, Sessao.idUtilizador);

            int linhas = stmt.executeUpdate();
            if (linhas > 0) {
                System.out.println(VERDE + "✔️ Conta criada com sucesso!" + RESET);
            } else {
                System.out.println(LARANJA + "❌ Falha ao criar conta." + RESET);
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao criar conta: " + e.getMessage() + RESET);
            throw e;
        }
    }

    // Listar todas as contas
    public void listarContas() throws SQLException {
        String sql = "SELECT idConta, titular, numConta, saldo, tipoConta, limite, taxa, idUtilizador FROM contas";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println(CIANO_CLARO + "\n===== LISTA DE CONTAS =====" + RESET);
            boolean encontrou = false;
            while (rs.next()) {
                encontrou = true;
                int idConta = rs.getInt("idConta");
                String titular = rs.getString("titular");
                int numConta = rs.getInt("numConta");
                double saldo = rs.getDouble("saldo");
                String tipoConta = rs.getString("tipoConta");
                Double limite = rs.getObject("limite") != null ? rs.getDouble("limite") : null;
                Double taxa = rs.getObject("taxa") != null ? rs.getDouble("taxa") : null;
                int idUtilizador = rs.getInt("idUtilizador");

                System.out.printf(
                    BRANCO + "ID: " + AZUL + "%d" + BRANCO +
                    " | Titular: " + CIANO_CLARO + "%s" + BRANCO +
                    " | Nº Conta: " + AZUL + "%d" + BRANCO +
                    " | Saldo: " + VERDE + "%.2f" + BRANCO +
                    " | Tipo: " + AMARELO + "%s" + BRANCO,
                    idConta, titular, numConta, saldo, tipoConta
                );
                if ("Ordem".equalsIgnoreCase(tipoConta)) {
                    System.out.printf(" | Limite: " + AMARELO + "%.2f" + BRANCO, limite != null ? limite : 0.0);
                } else if ("Poupanca".equalsIgnoreCase(tipoConta)) {
                    System.out.printf(" | Taxa: " + VERDE + "%.2f" + BRANCO, taxa != null ? taxa : 0.0);
                }
                System.out.printf(" | ID Utilizador: " + CIANO_CLARO + "%d" + RESET + "\n", idUtilizador);
            }
            if (!encontrou) {
                System.out.println(LARANJA + "Nenhuma conta encontrada !!!!" + RESET);
            }
            System.out.println(CIANO_CLARO + "===========================" + RESET);

        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao listar contas: " + e.getMessage() + RESET);
            throw e;
        }
    }

 // Apagar conta pelo número da conta
    public boolean apagarConta(int numConta) throws SQLException {
        // 1. Verificar quem criou a conta (idUtilizador associado)
        String sqlVerificar = "SELECT idUtilizador FROM contas WHERE numConta = ?";
        try (PreparedStatement stmtVerificar = conn.prepareStatement(sqlVerificar)) {
            stmtVerificar.setInt(1, numConta);
            try (ResultSet rs = stmtVerificar.executeQuery()) {
                if (rs.next()) {
                    int idCriador = rs.getInt("idUtilizador");

                    // 2. Verificar permissões
                    if (!Sessao.nivelAtual.equals("ADMIN") && Sessao.idUtilizador != idCriador) {
                        System.out.println(VERMELHO + "❌ Você não tem permissão para apagar esta conta!" + RESET);
                        return false;
                    }

                    // 3. Executar a exclusão se permitido
                    String sqlApagar = "DELETE FROM contas WHERE numConta = ?";
                    try (PreparedStatement stmtApagar = conn.prepareStatement(sqlApagar)) {
                        stmtApagar.setInt(1, numConta);
                        int linhasAfetadas = stmtApagar.executeUpdate();
                        if (linhasAfetadas > 0) {
                            System.out.println(VERDE + "✔️ Conta apagada com sucesso!" + RESET);
                            return true;
                        } else {
                            System.out.println(VERMELHO + "❌ Conta não encontrada para apagar !!!!" + RESET);
                        }
                    }
                } else {
                    System.out.println(VERMELHO + "⚠️ Conta não encontrada na base de dados!" + RESET);
                }
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao apagar conta: " + e.getMessage() + RESET);
        }
        return false;
    }

    	// Novo método auxiliar para verificar existência da conta
    public boolean contaExiste(int numConta) throws SQLException {
        String sql = "SELECT 1 FROM contas WHERE numConta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numConta);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // Depositar valor numa conta
    public boolean depositar(int numConta, double valor) throws SQLException {
        if (valor <= 0) {
            System.out.println(VERMELHO + "✘ O valor a depositar deve ser positivo." + RESET);
            throw new IllegalArgumentException("O valor a depositar deve ser positivo.");
        }
        // 🧠 Verificar se a conta existe
        String verificarSQL = "SELECT COUNT(*) FROM contas WHERE numConta = ?";
        try (PreparedStatement verificarStmt = conn.prepareStatement(verificarSQL)) {
            verificarStmt.setInt(1, numConta);
            ResultSet rs = verificarStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println(VERMELHO + "✘ Conta não encontrada para depósito!" + RESET);
                return false;
            }
        }
        // ✅ Atualizar o saldo
        String sql = "UPDATE contas SET saldo = saldo + ? WHERE numConta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, valor);
            stmt.setInt(2, numConta);
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println(VERDE + "✔ Depósito efetuado com sucesso!" + RESET);
                return true;
            } else {
                System.out.println(VERMELHO + "✘ Ocorreu uma falha no depósito!" + RESET);
                return false;
            }
        }
    }

    // Levantar valor de uma conta
    // Retornos possíveis: 0 - Conta não encontrada; 1 - Saldo insuficiente; 2 - Levantamento efetuado com sucesso
    public int levantar(int numConta, double valor) throws SQLException {
        if (valor <= 0) {
            System.out.println(VERMELHO + "❌ O valor a levantar deve ser positivo." + RESET);
            throw new IllegalArgumentException("O valor a levantar deve ser positivo.");
        }

        // 1º Verificar se a conta existe
        String verificaConta = "SELECT saldo FROM contas WHERE numConta = ?";
        double saldo = -1;
        try (PreparedStatement verificaStmt = conn.prepareStatement(verificaConta)) {
            verificaStmt.setInt(1, numConta);
            try (ResultSet rs = verificaStmt.executeQuery()) {
                if (rs.next()) {
                    saldo = rs.getDouble("saldo");
                } else {
                    return 0; // Conta não encontrada
                }
            }
        }

        // 2º Verificar saldo suficiente
        if (saldo < valor) {
            return 1; // Saldo insuficiente
        }

        // 3º Realizar o levantamento
        String levanta = "UPDATE contas SET saldo = saldo - ? WHERE numConta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(levanta)) {
            stmt.setDouble(1, valor);
            stmt.setInt(2, numConta);
            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                return 2; // Sucesso
            } else {
                return 0; // (por segurança, mas teoricamente nunca acontece aqui)
            }
        }
    }

    // Transferir valor entre contas
    public boolean transferir(int origemNum, int destinoNum, double valor) throws SQLException {
        if (valor <= 0) {
            System.out.println(VERMELHO + "❌ O valor a transferir deve ser positivo." + RESET);
            throw new IllegalArgumentException("O valor a transferir deve ser positivo.");
        }
        try {
            conn.setAutoCommit(false);

            // 1. Verificar se a conta de origem tem saldo suficiente
            String verificaSaldo = "SELECT saldo FROM contas WHERE numConta = ?";
            double saldoOrigem = 0;
            try (PreparedStatement checkStmt = conn.prepareStatement(verificaSaldo)) {
                checkStmt.setInt(1, origemNum);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        saldoOrigem = rs.getDouble("saldo");
                        if (saldoOrigem < valor) {
                            System.out.println(VERMELHO + "❌ Saldo insuficiente na conta de origem !!!!" + RESET);
                            conn.rollback();
                            return false;
                        }
                    } else {
                        System.out.println(VERMELHO + "❌ Conta de origem não encontrada !!!!" + RESET);
                        conn.rollback();
                        return false;
                    }
                }
            }

            // 2. Verificar se a conta de destino existe
            String verificaDestino = "SELECT 1 FROM contas WHERE numConta = ?";
            try (PreparedStatement destStmt = conn.prepareStatement(verificaDestino)) {
                destStmt.setInt(1, destinoNum);
                try (ResultSet rs = destStmt.executeQuery()) {
                    if (!rs.next()) {
                        System.out.println(VERMELHO + "❌ Conta de destino não encontrada !!!!" + RESET);
                        conn.rollback();
                        return false;
                    }
                }
            }

            // 3. Subtrair valor à conta de origem
            String debitar = "UPDATE contas SET saldo = saldo - ? WHERE numConta = ?";
            try (PreparedStatement debitarStmt = conn.prepareStatement(debitar)) {
                debitarStmt.setDouble(1, valor);
                debitarStmt.setInt(2, origemNum);
                debitarStmt.executeUpdate();
            }

            // 4. Acrescentar valor à conta de destino
            String creditar = "UPDATE contas SET saldo = saldo + ? WHERE numConta = ?";
            try (PreparedStatement creditarStmt = conn.prepareStatement(creditar)) {
                creditarStmt.setDouble(1, valor);
                creditarStmt.setInt(2, destinoNum);
                creditarStmt.executeUpdate();
            }

            // 5. Confirmar a transação
            conn.commit();
            System.out.println(VERDE + "✔️ Transferência efetuada com sucesso!" + RESET);
            return true;

        } catch (SQLException | IllegalArgumentException e) {
            conn.rollback();
            System.out.println(VERMELHO + "❌ Erro na transferência: " + e.getMessage() + RESET);
            return false;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    // Consultar conta por número (modo consola)
    public void consultarConta(int numConta) throws SQLException {
        String sql = "SELECT idConta, titular, numConta, saldo, tipoConta, limite, taxa, idUtilizador FROM contas WHERE numConta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numConta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idConta = rs.getInt("idConta");
                    String titular = rs.getString("titular");
                    double saldo = rs.getDouble("saldo");
                    String tipoConta = rs.getString("tipoConta");
                    Double limite = rs.getObject("limite") != null ? rs.getDouble("limite") : null;
                    Double taxa = rs.getObject("taxa") != null ? rs.getDouble("taxa") : null;
                    int idUtilizador = rs.getInt("idUtilizador");

                    System.out.println(CIANO_CLARO + "\n--- Detalhes da Conta ---" + RESET);
                    System.out.println(BRANCO + "ID: " + AZUL + idConta + RESET);
                    System.out.println(BRANCO + "Titular: " + CIANO_CLARO + titular + RESET);
                    System.out.println(BRANCO + "Nº Conta: " + AZUL + numConta + RESET);
                    System.out.println(BRANCO + "Saldo: " + VERDE + String.format("%.2f", saldo) + RESET);
                    System.out.println(BRANCO + "Tipo: " + AMARELO + tipoConta + RESET);
                    if ("Ordem".equalsIgnoreCase(tipoConta)) {
                        System.out.println(BRANCO + "Limite: " + AMARELO + (limite != null ? String.format("%.2f", limite) : "N/A") + RESET);
                    } else if ("Poupanca".equalsIgnoreCase(tipoConta)) {
                        System.out.println(BRANCO + "Taxa: " + VERDE + (taxa != null ? String.format("%.2f", taxa) : "N/A") + RESET);
                    }
                    System.out.println(BRANCO + "ID Utilizador: " + CIANO_CLARO + idUtilizador + RESET);
                } else {
                    System.out.println(VERMELHO + "❌ Conta não encontrada !!!!" + RESET);
                }
            }
        }
    }
    
    
 // Consultar detalhes da conta como texto (para interface)
    public String consultarContaSwing(int numConta) throws SQLException {
        StringBuilder sb = new StringBuilder();

        String sql = "SELECT idConta, titular, numConta, saldo, tipoConta, limite, taxa, idUtilizador FROM contas WHERE numConta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numConta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idConta = rs.getInt("idConta");
                    String titular = rs.getString("titular");
                    double saldo = rs.getDouble("saldo");
                    String tipoConta = rs.getString("tipoConta");
                    Double limite = rs.getObject("limite") != null ? rs.getDouble("limite") : null;
                    Double taxa = rs.getObject("taxa") != null ? rs.getDouble("taxa") : null;
                    int idUtilizador = rs.getInt("idUtilizador");

                    sb.append("ID: ").append(idConta).append("\n");
                    sb.append("Titular: ").append(titular).append("\n");
                    sb.append("Nº Conta: ").append(numConta).append("\n");
                    sb.append("Saldo: ").append(String.format("%.2f", saldo)).append(" €\n");
                    sb.append("Tipo: ").append(tipoConta).append("\n");

                    if ("Ordem".equalsIgnoreCase(tipoConta)) {
                        sb.append("Limite: ").append(limite != null ? String.format("%.2f", limite) : "N/A").append("\n");
                    } else if ("Poupanca".equalsIgnoreCase(tipoConta)) {
                        sb.append("Taxa: ").append(taxa != null ? String.format("%.2f", taxa) : "N/A").append("\n");
                    }

                    sb.append("ID Utilizador: ").append(idUtilizador);
                } else {
                    sb.append("❌ Conta não encontrada.");
                }
            }
        }

        return sb.toString();
    }

     
 // Listar a VIEW de contas com utilizadores (Consola)
    public void listarContasUtilizadores() throws SQLException {
        String sql = "SELECT numConta, saldo, tipoConta, nome, nivel FROM contas_utilizadores";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println(CIANO_CLARO + "\n===== CONTAS & UTILIZADORES =====" + RESET);
            boolean encontrou = false;
            while (rs.next()) {
                encontrou = true;
                int numeroConta = rs.getInt("numConta");
                double saldo = rs.getDouble("saldo");
                String tipoConta = rs.getString("tipoConta");
                String nome = rs.getString("nome");
                String nivel = rs.getString("nivel");

                System.out.printf(
                    AZUL + "Nº Conta: " + BRANCO + "%d" +
                    " | " + VERDE + "Saldo: " + BRANCO + "%.2f" +
                    " | " + AMARELO + "Tipo: " + BRANCO + "%s" +
                    " | " + CIANO_CLARO + "Titular: " + BRANCO + "%s" +
                    " | " + LARANJA + "Nível: " + BRANCO + "%s" + RESET + "\n",
                    numeroConta, saldo, tipoConta, nome, nivel
                );
            }
            if (!encontrou) {
                System.out.println(VERMELHO + "❌ Nenhum registo encontrado na VIEW !!" + RESET);
            }
            System.out.println(CIANO_CLARO + "===============================" + RESET);

        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao listar contas/utilizadores: " + e.getMessage() + RESET);
            throw e;
        }
    }
    
 // Retornar ResultSet da VIEW de contas com utilizadores (Interface Gráfica)
    public ResultSet obterContasUtilizadoresVIEW() throws SQLException {
        String sql = "SELECT numConta, saldo, tipoConta, nome, nivel FROM contas_utilizadores";
        PreparedStatement stmt = conn.prepareStatement(sql);
        return stmt.executeQuery();
    }
    
    // Criar contas bancárias efectivamente com registos na Base de Dados BVV
    public void criarContaNoBanco(int numConta, double saldo, String tipoConta, double limite, double taxa, int idUtilizador, String titular) throws SQLException {
        String sql = "INSERT INTO contas (numConta, saldo, tipoConta, limite, taxa, idUtilizador, titular) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numConta);
            stmt.setDouble(2, saldo);
            stmt.setString(3, tipoConta);

            if ("Ordem".equalsIgnoreCase(tipoConta)) {
                stmt.setDouble(4, limite);               // Limite preenchido
                stmt.setNull(5, java.sql.Types.DOUBLE);  // Taxa nula
            } else if ("Poupanca".equalsIgnoreCase(tipoConta)) {
                stmt.setNull(4, java.sql.Types.DOUBLE);  // Limite nulo
                stmt.setDouble(5, taxa);                 // Taxa preenchida
            } else {
                throw new SQLException("Tipo de conta inválido: " + tipoConta);
            }

            stmt.setInt(6, idUtilizador);
            stmt.setString(7, titular);

            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println(VERDE + "\u2713 Conta criada com sucesso na base de dados!" + RESET);
            } else {
                System.out.println(VERMELHO + "\u2717 Nenhuma linha foi inserida." + RESET);
            }
        }
    }

    public boolean contaPertenceAoUtilizador(int numeroConta, int idUtilizador) throws SQLException {
        String sql = "SELECT COUNT(*) FROM contas WHERE numConta = ? AND idUtilizador = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroConta);
            stmt.setInt(2, idUtilizador);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Se houver pelo menos 1 resultado, a conta pertence ao utilizador
                }
            }
        }
        return false;
    }
}
