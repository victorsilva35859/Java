package service;

import util.LoggerUtil;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import main.Sessao;

@SuppressWarnings("unused")
public class UserService {

    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String CIANO_CLARO = "\u001B[96m";
    //private static final String AMARELO = "\u001B[33m";
    private static final String BRANCO = "\u001B[37m";
    private static final String LARANJA = "\u001B[38;5;208m";

    private final Connection conn;

    public UserService(Connection conn) {
        this.conn = conn;
    }

    private boolean validarSenhaForte(String senha) {
        if (senha == null || senha.length() < 8 || senha.length() > 20) {
            System.out.println(VERMELHO + "❌ Senha deve ter entre 8 e 20 dígitos." + RESET);
            return false;
        }

        if (!senha.matches(".*[A-Z].*")) {
            System.out.println(LARANJA + "❗ Senha deve conter pelo menos uma letra maiúscula." + RESET);
            return false;
        }

        if (!senha.matches(".*[a-z].*")) {
            System.out.println(LARANJA + "❗ Senha deve conter pelo menos uma letra minúscula." + RESET);
            return false;
        }

        if (!senha.matches(".*[0-9].*")) {
            System.out.println(LARANJA + "❗ Senha deve conter pelo menos um algarismo." + RESET);
            return false;
        }

        if (!senha.matches(".*[^a-zA-Z0-9].*")) {
            System.out.println(LARANJA + "❗ Senha deve conter pelo menos um símbolo (ex: @, #, $, %)." + RESET);
            return false;
        }

        return true;
    }
    
    // Método de criptografia (privado)
    public static String criptografarSenha(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(senha.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao criptografar senha: " + e.getMessage());
        }
    }

    public void criarUtilizador(String nome, String senha, String nivel) throws SQLException {
    	if (!validarSenhaForte(senha)) {
    		System.out.println(VERMELHO + "A senha tem que atender aos critérios!" + RESET);
            return;
        }
    	String senhaCriptografada = criptografarSenha(senha);
    	String sql = "{call CriarUtilizador(?, ?, ?)}";		//Boa prática (CallableStatement) sempre que for para executar uma procedure
        //String sql = "INSERT INTO utilizadores (nome, senha, nivel) VALUES (?, ?, ?)" - Ideal p/comando SQL Directo
    	 try (CallableStatement stmt = conn.prepareCall(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, senhaCriptografada);
            stmt.setString(3, nivel);
            stmt.executeUpdate();
            System.out.println(VERDE + "✔ Utilizador criado com sucesso." + RESET);
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao criar utilizador: " + e.getMessage() + RESET);
        }
    }

    public void listarUtilizador() throws SQLException {
        String sql = "SELECT * FROM utilizadores";
        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            System.out.println(CIANO_CLARO + "\n--- LISTA DE UTILIZADORES ---" + RESET);
            boolean existe = false;
            while (rs.next()) {
                existe = true;
                int id = rs.getInt("idUtilizador");
                String nome = rs.getString("nome");
                String nivel = rs.getString("nivel");
                System.out.println(BRANCO + "ID: " + id + RESET
                    + CIANO_CLARO + " | Nome: " + nome + RESET
                    + LARANJA + " | Nível: " + nivel + RESET);
            }
            if (!existe) {
				System.out.println(VERMELHO + "Nenhum utilizador encontrado !!!!" + RESET);
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao listar utilizadores: " + e.getMessage() + RESET);
        }
    }
    
    public List<Object[]> listarTodos() throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT idUtilizador, nome, nivel FROM utilizadores";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Object[] linha = {
                    rs.getInt("idUtilizador"),
                    rs.getString("nome"),
                    rs.getString("nivel")
                };
                lista.add(linha);
            }
        }
        return lista;
    }
    
    public boolean autenticar(String nome, String senha) {
        // ⚠️ Limpar sessão anterior
        Sessao.utilizadorAtual = "";
        Sessao.nivelAtual = "";
        Sessao.idUtilizador = 0;

        String sql = "SELECT * FROM utilizadores WHERE nome = ? AND senha = ?";
        String senhaCriptografada = criptografarSenha(senha);

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, senhaCriptografada);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Guardar nome e nível na Sessão
                    Sessao.utilizadorAtual = rs.getString("nome");
                    Sessao.nivelAtual = rs.getString("nivel");
                    Sessao.idUtilizador = rs.getInt("idUtilizador");

                    // 🔍 Debug e consola
                    System.out.println("🔍 DEBUG LOGIN -> ID: " + Sessao.idUtilizador +
                                       " | Nome: " + Sessao.utilizadorAtual +
                                       " | Nível: " + Sessao.nivelAtual);

                    System.out.println(VERDE + "✔ Login efetuado com sucesso. Bem-vindo, "
                                       + Sessao.utilizadorAtual + " (" + Sessao.nivelAtual + ")!" + RESET);

                    // 📁 Log de acesso
                    LoggerUtil.logAcesso("Login bem-sucedido: " + nome + " (" + Sessao.nivelAtual + ")");
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao autenticar: " + e.getMessage() + RESET);
            LoggerUtil.logErro("Erro na autenticação de '" + nome + "': " + e.getMessage());
            return false;
        }

        System.out.println(VERMELHO + "❌ Utilizador ou senha incorretos." + RESET);
        LoggerUtil.logNegado("Tentativa de login falhada: " + nome);
        return false;
    }


    public void atualizarUtilizador(int id, String nome, String senha, String nivel) throws SQLException {
        String sql = "UPDATE utilizadores SET nome = ?, senha = ?, nivel = ? WHERE idUtilizador = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            String senhaCriptografada = criptografarSenha(senha);
            stmt.setString(2, senhaCriptografada);
            stmt.setString(3, nivel);
            stmt.setInt(4, id);
            int linhas = stmt.executeUpdate();
            if (linhas > 0) {
                System.out.println(VERDE + "✔ Utilizador atualizado com sucesso." + RESET);
            } else {
                System.out.println(VERMELHO + "❌ Utilizador não encontrado !!!!" + RESET);
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao atualizar utilizador: " + e.getMessage() + RESET);
        }
    }

    public void excluirUtilizador(int id) throws SQLException {
        String sql = "DELETE FROM utilizadores WHERE idUtilizador = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int linhas = stmt.executeUpdate();
            if (linhas > 0) {
                System.out.println(VERDE + "✔ Utilizador excluído com sucesso." + RESET);
            } else {
                System.out.println(VERMELHO + "❌ Utilizador não encontrado !!!!" + RESET);
            }
        } catch (SQLException e) {
            System.out.println(VERMELHO + "❌ Erro ao excluir utilizador: " + e.getMessage() + RESET);
        }
    }
    
    public boolean existeUtilizador(int id) {
        String sql = "SELECT 1 FROM utilizadores WHERE idUtilizador = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            // Aqui podes fazer log ou lançar exceção, como preferires
            return false;
        }
    }
}
