package tarefa1POO;

public interface Avaliacao {
    void avaliarPaciente(Paciente paciente);
}
