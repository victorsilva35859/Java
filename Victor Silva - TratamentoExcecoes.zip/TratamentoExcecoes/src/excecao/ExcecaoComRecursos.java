package excecao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ExcecaoComRecursos {

	public static void main(String[] args) {
		try(BufferedReader reader=new BufferedReader(new FileReader("teste.txt"))){
			String linha="";
			linha=reader.readLine();
			System.out.println(linha);
		}catch(IOException e) {
			System.out.println("Erro: " + e.getMessage());
		}

	}

}
