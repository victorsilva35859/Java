package excecao;

public class MinhaExcecaoRunTime extends RuntimeException{

	public MinhaExcecaoRunTime(String mensagem) {
		super(mensagem);
	}
}
