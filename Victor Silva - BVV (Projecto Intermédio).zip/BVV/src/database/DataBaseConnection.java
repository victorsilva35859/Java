package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection implements AutoCloseable {
	 private static final String VERMELHO = "\u001B[31m";
	 private static final String BRANCO = "\u001B[37m";

    private final Connection conn;
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=BVV;user=Victor(sa);password=Cinel2025;encrypt=true;trustServerCertificate=true";

    public DataBaseConnection() throws SQLException {
        this.conn = DriverManager.getConnection(URL);
    }

    public Connection getConnection() {
        return conn;
    }

    @Override
    public void close() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println(BRANCO + "✔️ Ligação fechada");
            }
        } catch (SQLException e) {
            System.err.println(VERMELHO + "❌ Erro ao fechar a ligação: " + e.getMessage());
        }
    }
}

