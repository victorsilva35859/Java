package Ex4;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

 // Representa o servidor que aceita vários clientes simultaneamente,criando uma nova thread (ClienteComunicador) para cada ligação.
public class ServidorComThreads {

    // Códigos ANSI para cor na consola
	public static final String VERMELHO = "\u001B[31m";
    private static final String RESET = "\u001B[0m";
    public static final String AZUL = "\u001B[34m";

    public static void main(String[] args) {
        int porta = 5000;

        try (ServerSocket servidor = new ServerSocket(porta)) {
            System.out.println(AZUL + getTimestamp() + " Servidor > À escuta na porta " + porta + "..." + RESET);

            // Ciclo infinito para aceitar clientes continuamente
            while (true) {
                Socket cliente = servidor.accept(); // Espera por ligação
                System.out.println(VERMELHO + getTimestamp() + " Servidor > Novo cliente ligado: " +
                                   cliente.getInetAddress().getHostAddress() + RESET);

                // Cria e inicia uma nova thread para comunicar com este cliente
                ClienteComunicador comunicador = new ClienteComunicador(cliente);
                comunicador.start();
            }

        } catch (IOException e) {
            System.out.println("Servidor > Erro: " + e.getMessage());
        }
    }

    //Devolve a hora atual formatada para exibir nas mensagens.
    private static String getTimestamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return "[" + formatter.format(LocalDateTime.now()) + "]";
    }
}


