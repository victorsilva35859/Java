package Ex3;

public class Contador {

	private int valor=0;
	
	public synchronized void incrementar(String threadName) {
		valor++;
		System.out.println(threadName + " aumentou o valor para " + valor);
		try {
			Thread.sleep(100);
		}catch(InterruptedException e) {
			System.out.println("Erro: " + threadName);
		}
	}
	
	public int getValor() {
		return valor;
	}

}
