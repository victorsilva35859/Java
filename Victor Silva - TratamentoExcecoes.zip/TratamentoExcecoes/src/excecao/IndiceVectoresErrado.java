package excecao;

public class IndiceVectoresErrado {

	public static void main(String[] args) {
		
		int num = 10;
		int div = 0;

		try {
		    if (div == 0) {
		        throw new MinhaExcecaoRunTime("Não podes dividir por zero, Victor!");
		    }
		    int res = num / div; // agora só será feito se div != 0
		} catch (MinhaExcecaoRunTime e) {
		    System.out.println("Erro personalizado: " + e.getMessage());
		}
	}
}
