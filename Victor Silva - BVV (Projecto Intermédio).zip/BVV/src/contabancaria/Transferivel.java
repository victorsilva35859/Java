package contabancaria;

public interface Transferivel {
    boolean transferirPara(Contabancaria destino, double valor);
}
