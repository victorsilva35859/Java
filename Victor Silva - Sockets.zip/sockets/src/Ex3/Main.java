package Ex3;

public class Main {
    public static void main(String[] args) {
        Contador contador = new Contador();

        // Cria os Runnable
        MinhaRunnable tarefa1 = new MinhaRunnable(contador, "Thread-1");
        MinhaRunnable tarefa2 = new MinhaRunnable(contador, "Thread-2");

        // Cria as Threads, associando-lhes os Runnable e dando nome
        Thread thread1 = new Thread(tarefa1, "T1");
        Thread thread2 = new Thread(tarefa2, "T2");

        // Inicia as Threads
        thread1.start();
        thread2.start();

        // Aguarda a conclusão das duas threads
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Erro ao aguardar threads.");
        }

        System.out.println("\nValor final do contador: " + contador.getValor());
    }
}

