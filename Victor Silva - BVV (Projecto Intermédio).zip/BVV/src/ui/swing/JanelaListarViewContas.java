package ui.swing;

import service.ContaService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JanelaListarViewContas extends JFrame {
	private static final long serialVersionUID = 1L;

    public JanelaListarViewContas(ContaService contaService) {
        setTitle("Lista de Contas + Utilizadores (VIEW)");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Cabeçalhos da tabela
        String[] colunas = {"Nº Conta", "Saldo", "Tipo", "Utilizador", "Nível"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabela);
        add(scrollPane, BorderLayout.CENTER);

        // Botão Fechar
        JButton btnFechar = new JButton("Fechar");
        btnFechar.addActionListener(e -> dispose());
        JPanel painelBotoes = new JPanel();
        painelBotoes.add(btnFechar);
        add(painelBotoes, BorderLayout.SOUTH);

        // Carregar dados da VIEW
        try {
            ResultSet rs = contaService.obterContasUtilizadoresVIEW();
            while (rs.next()) {
                int numConta = rs.getInt("numConta");
                double saldo = rs.getDouble("saldo");
                String tipo = rs.getString("tipoConta");
                String titular = rs.getString("nome");
                String nivel = rs.getString("nivel");
                modelo.addRow(new Object[]{numConta, String.format("%.2f", saldo), tipo, titular, nivel});
            }
            rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar dados da VIEW: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }

        setVisible(true);
    }
}
