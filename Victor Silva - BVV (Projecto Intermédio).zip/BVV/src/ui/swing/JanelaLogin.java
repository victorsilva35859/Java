package ui.swing;

import javax.swing.*;
import service.UserService; // Usa o teu já existente!
import database.DataBaseConnection;
import main.Sessao;

import java.awt.event.*;
import java.sql.Connection;


@SuppressWarnings({ "serial", "unused" })
public class JanelaLogin extends JFrame {
    private JTextField campoNome;
    private JPasswordField campoSenha;
    private JButton botaoEntrar;
    private final UserService userService;
    private final Connection conn;
    
    public JanelaLogin(UserService userService, Connection conn) {
        super("Login BVV");
        this.userService = userService;
        this.conn = conn;
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel labelNome = new JLabel("Nome:");
        labelNome.setBounds(30, 30, 60, 25);
        add(labelNome);

        campoNome = new JTextField();
        campoNome.setBounds(90, 30, 150, 25);
        add(campoNome);

        JLabel labelSenha = new JLabel("Senha:");
        labelSenha.setBounds(30, 65, 60, 25);
        add(labelSenha);

        campoSenha = new JPasswordField();
        campoSenha.setBounds(90, 65, 150, 25);
        add(campoSenha);

        botaoEntrar = new JButton("Entrar");
        getRootPane().setDefaultButton(botaoEntrar);
        botaoEntrar.setBounds(90, 110, 100, 30);
        add(botaoEntrar);

        botaoEntrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = campoNome.getText();
                String senha = new String(campoSenha.getPassword());
                boolean loginOK = userService.autenticar(nome, senha);
                if (loginOK) {
                    JOptionPane.showMessageDialog(JanelaLogin.this, "Login efetuado com sucesso!", "Bem-vindo", JOptionPane.INFORMATION_MESSAGE);
                    new MenuPrincipal(Sessao.utilizadorAtual, Sessao.nivelAtual, userService, conn).setVisible(true);
                    dispose(); // Fecha a janela de login
                } else {
                    JOptionPane.showMessageDialog(JanelaLogin.this, "Utilizador ou senha inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        }); // <--- Fecho o addActionListener

    } // ...aqui termina o construtor da minha JanelaLogin
}
