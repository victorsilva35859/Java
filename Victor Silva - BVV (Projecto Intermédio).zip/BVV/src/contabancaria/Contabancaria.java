package contabancaria;

public class Contabancaria implements Transferivel {

    private String titular;
    private int numConta;
    private double saldo;
    private TipoConta tipoConta;

    public enum TipoConta {
        Ordem,
        Poupanca
    }

    // Construtor com validações
    public Contabancaria(String titular, int numConta, double saldo, TipoConta tipoConta) throws DadosInvalidosException {
        StringBuilder erros = new StringBuilder();

        if (titular == null || titular.isEmpty()) {
            erros.append("❌ Titular inválido. O nome não pode estar vazio.\n");
        }

        if (saldo <= 0) {
            erros.append("❌ Saldo inválido. O valor deve ser maior que zero.\n");
        }

        if (erros.length() > 0) {
            throw new DadosInvalidosException(erros.toString());
        }

        this.titular = titular;
        this.numConta = numConta;
        this.saldo = saldo;
        this.tipoConta = tipoConta;
    }

    // Getters e setters
    public String getTitular() {
        return titular;
    }

    public int getNumConta() {
        return numConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public TipoConta getTipoConta() {
        return tipoConta;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setTipoConta(TipoConta tipoConta) {
        this.tipoConta = tipoConta;
    }

    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String AZUL = "\u001B[34m";
    private static final String AMARELO = "\u001B[33m";

    public void mostrarDados() {
        System.out.println(AZUL + "Titular: " + RESET + titular);
        System.out.println(AZUL + "Número da Conta: " + RESET + numConta);
        System.out.println(AZUL + "Saldo: " + RESET + String.format("%.2f€", saldo));
        System.out.println(AZUL + "Tipo de Conta: " + RESET + tipoConta);
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.printf(VERDE + "💵 Foi depositado %.2f€, ficou com um saldo de %.2f€\n" + RESET, valor, saldo);
        } else {
            System.out.println(VERMELHO + "O valor do depósito tem que ser positivo." + RESET);
        }
    }

    public boolean levantar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
            System.out.printf(AMARELO + "💸 Levantamento de %.2f€ realizado. Novo saldo: %.2f€\n" + RESET, valor, saldo);
            return true;
        } else {
            System.out.printf(VERMELHO + "❌ Levantamento de %.2f€ inválido. Saldo insuficiente (%.2f€).\n" + RESET, valor, saldo);
            return false;
        }
    }

    public boolean transferirPara(Contabancaria destino, double valor) {
        if (valor > 0 && valor <= this.saldo) {
            this.saldo -= valor;

            // Verifica se o destino é ContaPoupanca (para não aplicar juros)
            if (destino instanceof ContaPoupanca) {
                ((ContaPoupanca) destino).depositarSemJuros(valor);
            } else {
                destino.depositar(valor);
            }

            System.out.println(VERDE + "✅ Transferência efetuada com sucesso." + RESET);
            System.out.printf(AMARELO + "💸 Valor transferido: %.2f€\n" + RESET, valor);
            System.out.printf(AZUL + "🏛️ Saldo atual da conta origem: %.2f€\n" + RESET, this.saldo);
            return true;
        } else {
            System.out.println(VERMELHO + "✘ Falha na transferência: saldo insuficiente." + RESET);
            return false;
        }
    }
} 
