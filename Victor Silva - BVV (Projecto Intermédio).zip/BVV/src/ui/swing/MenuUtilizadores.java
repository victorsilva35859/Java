package ui.swing;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

import service.UserService;

@SuppressWarnings("serial")
public class MenuUtilizadores extends JFrame {
	private final UserService userService;
    
    @SuppressWarnings("unused")
	private final String nome;
    @SuppressWarnings("unused")
	private final String nivel;

    @SuppressWarnings("unused")
	private final Connection conn;

    @SuppressWarnings("unused")
	public MenuUtilizadores(String nome, String nivel, UserService userService, Connection conn) {
        this.nome = nome;
        this.nivel = nivel;
        this.userService = userService;
        this.conn = conn;

        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Só fecha esta janela

        setLayout(new GridLayout(6, 1, 10, 10));
        JPanel painelPrincipal = new JPanel(new BorderLayout()); // painel principal com layout

        JLabel lblTitulo = new JLabel(
            "<html><div style='text-align: center; color:#003366; font-size:12px;'>"
            + "👥 <b>Menu de Gestão de Utilizadores</b>"+ " (" + nivel.toUpperCase() + ")!</b>"
            + "</div></html>"
        );
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Margem interna superior/inferior
        painelPrincipal.add(lblTitulo, BorderLayout.NORTH); // Adiciona o cabeçalho ao topo
        
        JPanel painelBotoes = new JPanel(new GridLayout(5, 1, 10, 10));

     // Carregar e redimensionar o ícone Criar Utilizador
     ImageIcon iconCriarOriginal = new ImageIcon(getClass().getResource("/resources/Criar Utilizador.png"));
     Image imgRedimensionada = iconCriarOriginal.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
     ImageIcon iconCriar = new ImageIcon(imgRedimensionada);

     // Criar o botão com ícone redimensionado Criar Utilizador
     JButton btnCriar = new JButton("Criar utilizador", iconCriar);
     btnCriar.setHorizontalAlignment(SwingConstants.CENTER); // Texto + Ícone centrados horizontalmente
     btnCriar.setVerticalTextPosition(SwingConstants.CENTER); // Texto no centro verticalmente
     btnCriar.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone

     // Carregar e redimensionar o ícone para Listar Utilizadores
     ImageIcon iconListarOriginal = new ImageIcon(getClass().getResource("/resources/Listar Utilizadores.png"));
     Image imgListarRedimensionada = iconListarOriginal.getImage().getScaledInstance(22, 22, Image.SCALE_SMOOTH);
     ImageIcon iconListar = new ImageIcon(imgListarRedimensionada);

     // Criar o botão com ícone Listar Utilizadores
     JButton btnListar = new JButton("Listar utilizadores", iconListar);
     btnListar.setHorizontalAlignment(SwingConstants.CENTER);  // Texto + Ícone centrados horizontalmente
     btnListar.setVerticalTextPosition(SwingConstants.CENTER);  // Texto no centro verticalmente
     btnListar.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone

     // Carregar e redimensionar o ícone para Atualizar Utilizador
     ImageIcon iconAtualizarOriginal = new ImageIcon(getClass().getResource("/resources/AtualizarUtilizador.png"));
     Image imgAtualizarRedimensionada = iconAtualizarOriginal.getImage().getScaledInstance(22, 22, Image.SCALE_SMOOTH);
     ImageIcon iconAtualizar = new ImageIcon(imgAtualizarRedimensionada);

     // Criar o botão com ícone Atualizar Utilizador
     JButton btnAtualizar = new JButton("Atualizar Utilizador", iconAtualizar);
     btnAtualizar.setHorizontalAlignment(SwingConstants.CENTER);  // Texto + Ícone centrados horizontalmente
     btnAtualizar.setVerticalTextPosition(SwingConstants.CENTER);  // Texto no centro verticalmente
     btnAtualizar.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone
     
     // Carregar e redimensionar o ícone para Excluir Utilizador
     ImageIcon iconExcluirOriginal = new ImageIcon(getClass().getResource("/resources/Excluir Utilizador.png"));
     Image imgExcluirRedimensionada = iconExcluirOriginal.getImage().getScaledInstance(22, 22, Image.SCALE_SMOOTH);
     ImageIcon iconExcluir = new ImageIcon(imgExcluirRedimensionada);

     // Criar o botão com ícone Excluir Utilizador
     JButton btnExcluir = new JButton("Excluir Utilizador", iconExcluir);
     btnExcluir.setHorizontalAlignment(SwingConstants.CENTER);  // Texto + Ícone centrados horizontalmente
     btnExcluir.setVerticalTextPosition(SwingConstants.CENTER);  // Texto no centro verticalmente
     btnExcluir.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone
     
     // Carregar e redimensionar o ícone para Voltar
     ImageIcon iconVoltarOriginal = new ImageIcon(getClass().getResource("/resources/Voltar.png"));
     Image imgVoltarRedimensionada = iconVoltarOriginal.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
     ImageIcon iconVoltar = new ImageIcon(imgVoltarRedimensionada);

     // Criar o botão com ícone Voltar
     JButton btnVoltar = new JButton("Voltar", iconVoltar);
     btnVoltar.setHorizontalAlignment(SwingConstants.CENTER);  // Texto + Ícone centrados horizontalmente
     btnVoltar.setVerticalTextPosition(SwingConstants.CENTER);  // Texto no centro verticalmente
     btnVoltar.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone
     
     painelPrincipal.add(painelBotoes, BorderLayout.CENTER);

        // Junta tudo à janela
        add(painelPrincipal);

        add(btnCriar);
        add(btnListar);
        add(btnAtualizar);
        add(btnExcluir);
        add(btnVoltar);
        
        

        // 1. Criar utilizador
        btnCriar.addActionListener(e -> {
            JTextField campoNome = new JTextField();
            JPasswordField campoSenha = new JPasswordField();
            JPasswordField campoConfirmar = new JPasswordField();
            JComboBox<String> comboNivel = new JComboBox<>(new String[]{"ADMIN", "USER"});

            Object[] campos = {
                "Nome:", campoNome,
                "Senha:", campoSenha,
                "Confirmar Senha:", campoConfirmar,
                "Nível:", comboNivel
            };

            int resultado = JOptionPane.showConfirmDialog(this, campos, "Criar Utilizador", JOptionPane.OK_CANCEL_OPTION);
            if (resultado == JOptionPane.OK_OPTION) {
                String novoNome = campoNome.getText().trim();
                String senha = new String(campoSenha.getPassword());
                String confirmar = new String(campoConfirmar.getPassword());
                String novoNivel = (String) comboNivel.getSelectedItem();

                // Validação: campos vazios
                if (nome.isEmpty() || senha.isEmpty() || confirmar.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Todos os campos são obrigatórios.", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Validação: senhas coincidirem
                if (!senha.equals(confirmar)) {
                    JOptionPane.showMessageDialog(this, "As senhas não coincidem!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Aqui chamo o meu método para criar o utilizador
                try {
                    userService.criarUtilizador(novoNome, senha, novoNivel);
                    JOptionPane.showMessageDialog(this, "Utilizador criado com sucesso!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Erro ao criar utilizador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 2. Listar utilizadores
        btnListar.addActionListener(e -> new JanelaListarUtilizadores(userService).setVisible(true));

        // 3. Atualizar utilizador
        btnAtualizar.addActionListener(e -> {
            atualizarUtilizador();
        });

        // 4. Excluir utilizador
        btnExcluir.addActionListener(e -> {
            excluirUtilizador();
        });

        // 0. Voltar
        btnVoltar.addActionListener(e -> {
            new MenuPrincipal(nome, nivel, userService, conn).setVisible(true);
            dispose(); // Fecha esta janela
        });
    }

  
    private void atualizarUtilizador() {
        // Passo 1: Pedir o ID do utilizador a atualizar
        String inputId = JOptionPane.showInputDialog(this, "ID do utilizador a atualizar:", "Atualizar Utilizador", JOptionPane.QUESTION_MESSAGE);
        if (inputId == null || inputId.trim().isEmpty()) {
            // Cancelado ou vazio
            return;
        }
        int id;
        try {
            id = Integer.parseInt(inputId.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!userService.existeUtilizador(id)) {
            JOptionPane.showMessageDialog(this, "O utilizador com o ID " + id + " não existe!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Passo 2: Pedir os novos dados
        JTextField campoNome = new JTextField();
        JPasswordField campoSenha = new JPasswordField();
        JComboBox<String> comboNivel = new JComboBox<>(new String[]{"ADMIN", "USER"});

        Object[] campos = {
            "Novo Nome:", campoNome,
            "Nova Senha:", campoSenha,
            "Novo Nível:", comboNivel
        };

        int resultado = JOptionPane.showConfirmDialog(this, campos, "Atualizar Utilizador", JOptionPane.OK_CANCEL_OPTION);
        if (resultado == JOptionPane.OK_OPTION) {
            String nome = campoNome.getText().trim();
            String senha = new String(campoSenha.getPassword());
            String nivel = (String) comboNivel.getSelectedItem();

            if (nome.isEmpty() || senha.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome e senha não podem ser vazios!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Passo 3: Chamar o serviço para atualizar
            try {
                userService.atualizarUtilizador(id, nome, senha, nivel);
                JOptionPane.showMessageDialog(this, "Utilizador atualizado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar utilizador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void excluirUtilizador() {
        String inputId = JOptionPane.showInputDialog(this, "ID do utilizador a eliminar:", "Eliminar Utilizador", JOptionPane.QUESTION_MESSAGE);
        if (inputId == null || inputId.trim().isEmpty())
            return; // Cancelado ou vazio

        int id;
        try {
            id = Integer.parseInt(inputId.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verifica se existe o utilizador
        if (!userService.existeUtilizador(id)) {
            JOptionPane.showMessageDialog(this, "Não existe nenhum utilizador com esse ID!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Confirmação antes de eliminar
        int opcao = JOptionPane.showConfirmDialog(this, "Tem a certeza que quer eliminar o utilizador com ID " + id + "?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION) {
            try {
                userService.excluirUtilizador(id);
                JOptionPane.showMessageDialog(this, "Utilizador eliminado com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao eliminar utilizador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    
    /*
	 * private void criarUtilizador() {
	 * 
	 * }
	 * 
	 * private void listarUtilizadores() {
	 * 
	 * }
	 */
}
