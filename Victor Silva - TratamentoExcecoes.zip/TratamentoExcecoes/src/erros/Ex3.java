package erros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Ex3 {

    public static void main(String[] args) {

        Connection conn = null;

        try {
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=BVV;user=Victor(sa);password=Cinel2025;encrypt=true;trustServerCertificate=true");
            Statement stmt = conn.createStatement();
            stmt.execute("SELECT * FROM tabela");
            System.out.println("Sucesso");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // Fecha a conexão, se foi aberta
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Ligação fechada com sucesso.");
                } catch (SQLException e) {
                    System.out.println("Erro ao fechar ligação: " + e.getMessage());
                }
            }
        }
    }
}


