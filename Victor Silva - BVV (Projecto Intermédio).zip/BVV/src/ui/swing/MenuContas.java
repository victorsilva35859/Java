package ui.swing;

import javax.swing.*;

import contabancaria.Contabancaria;
import contabancaria.Contabancaria.TipoConta;
import contabancaria.DadosInvalidosException;
import main.MainSwing;
import main.Sessao;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.sql.SQLException;

import service.ContaService;
import service.UserService;
import ui.swing.MenuPrincipal;

@SuppressWarnings({ "serial", "unused" })
public class MenuContas extends JFrame {
private final ContaService contaService;
private final JFrame janelaPrincipal;

//@SuppressWarnings({ "serial", "unused" })
public MenuContas(ContaService contaService, JFrame janelaPrincipal) {
    super("Gestão de Contas Bancárias");
    this.contaService = contaService;
    this.janelaPrincipal = janelaPrincipal;

    setSize(500, 700);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    setLayout(new BorderLayout());

    // Cabeçalho com nome da sessão
    JLabel lblTitulo = new JLabel(
        "<html><div style='text-align: center; color:#003366; font-size:12px;'>"
        + "💰 <b>Menu de Contas Bancárias</b> (" + Sessao.nivelAtual.toUpperCase() + ")!</b>"
        + "</div></html>"
    );
    lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
    lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
    add(lblTitulo, BorderLayout.NORTH);

    JPanel painelBotoes = new JPanel(new GridLayout(9, 1, 10, 10));
    
 // Carregar e redimensionar o ícone Criar Utilizador
    ImageIcon iconCriarContaOriginal = new ImageIcon(getClass().getResource("/resources/Criar Conta.png"));
    Image imgRedimensionada = iconCriarContaOriginal.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
    ImageIcon iconCriarConta = new ImageIcon(imgRedimensionada);

    // Criar o botão com ícone redimensionado Criar Utilizador
    JButton btnCriarConta = new JButton("Criar conta", iconCriarConta);
    btnCriarConta.setHorizontalAlignment(SwingConstants.CENTER); // Texto + Ícone centrados horizontalmente
    btnCriarConta.setVerticalTextPosition(SwingConstants.CENTER); // Texto no centro verticalmente
    btnCriarConta.setHorizontalTextPosition(SwingConstants.RIGHT); // Texto à direita do ícone
    
	btnCriarConta.addActionListener(e -> abrirPainelCriarConta());
	painelBotoes.add(btnCriarConta);
	

    JButton btnListar = new JButton("2 - Listar contas");
    painelBotoes.add(btnListar);

    JButton btnApagar = new JButton("3 - Apagar conta");
    painelBotoes.add(btnApagar);

    JButton btnDepositar = new JButton("4 - Depositar");
    painelBotoes.add(btnDepositar);

    JButton btnLevantar = new JButton("5 - Levantar");
    painelBotoes.add(btnLevantar);

    JButton btnTransferir = new JButton("6 - Transferir");
    painelBotoes.add(btnTransferir);

    JButton btnConsultar = new JButton("7 - Consultar conta");
    painelBotoes.add(btnConsultar);

    JButton btnListarView = new JButton("8 - Listar Contas + Utilizadores (VIEW)");
    painelBotoes.add(btnListarView);

    JButton btnVoltar = new JButton("0 - Voltar");
    painelBotoes.add(btnVoltar);

    add(painelBotoes, BorderLayout.CENTER);

    
    btnListar.addActionListener(e -> {
        new JanelaListarContas(contaService).setVisible(true);
    });

    btnApagar.addActionListener(e -> {
        String input = JOptionPane.showInputDialog(this, "Digite o número da conta a apagar:");
        if (input == null || input.trim().isEmpty()) {
            return; // Cancelado ou vazio
        }
        try {
            int numeroConta = Integer.parseInt(input.trim());

            // Validação de permissões
            if (Sessao.nivelAtual.equalsIgnoreCase("USER")) {
                boolean pertence = contaService.contaPertenceAoUtilizador(numeroConta, Sessao.idUtilizador);
                if (!pertence) {
                    JOptionPane.showMessageDialog(this,
                            "❌ Não tem permissão para apagar esta conta. Só pode apagar contas criadas por si.",
                            "Acesso Negado", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            if (!contaService.contaExiste(numeroConta)) {
                JOptionPane.showMessageDialog(this, "❌ Conta não encontrada!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int confirmacao = JOptionPane.showConfirmDialog(
                this,
                "Tem a certeza que deseja apagar a conta nº " + numeroConta + "?",
                "Confirmar Apagar Conta",
                JOptionPane.YES_NO_OPTION
            );

            if (confirmacao == JOptionPane.YES_OPTION) {
                boolean apagado = contaService.apagarConta(numeroConta);
                if (apagado) {
                    JOptionPane.showMessageDialog(this, "✔ Conta apagada com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Erro ao apagar a conta!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Número inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException exSql) {
            JOptionPane.showMessageDialog(this, "Erro ao apagar a conta: " + exSql.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnDepositar.addActionListener(e -> {
        String input = JOptionPane.showInputDialog(
            this, "Digite o número da conta para depositar:", "Depósito", JOptionPane.QUESTION_MESSAGE);

        if (input == null || input.trim().isEmpty()) {
            return; // cancelado
        }
        try {
            int numeroConta = Integer.parseInt(input.trim());
            String valorStr = JOptionPane.showInputDialog(
                this, "Digite o valor a depositar:", "Depósito", JOptionPane.QUESTION_MESSAGE);
            if (valorStr == null || valorStr.trim().isEmpty()) {
                return;
            }
            double valor = Double.parseDouble(valorStr.trim());
            boolean sucesso = contaService.depositar(numeroConta, valor);
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Depósito realizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Conta não encontrada.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Entrada inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao realizar depósito: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnLevantar.addActionListener(e -> {
        String input = JOptionPane.showInputDialog(
            this, "Digite o número da conta para levantar:", "Levantamento", JOptionPane.QUESTION_MESSAGE);

        if (input == null || input.trim().isEmpty()) {
            return; // Cancelado
        }
        try {
            int numeroConta = Integer.parseInt(input.trim());
            String valorStr = JOptionPane.showInputDialog(
                this, "Digite o valor a levantar:", "Levantamento", JOptionPane.QUESTION_MESSAGE);

            if (valorStr == null || valorStr.trim().isEmpty()) {
                return;
            }
            double valor = Double.parseDouble(valorStr.trim());
            int resultado = contaService.levantar(numeroConta, valor);
            switch (resultado) {
                case 0:
                    JOptionPane.showMessageDialog(this, "Conta não encontrada.", "Erro", JOptionPane.ERROR_MESSAGE);
                    break;
                case 1:
                    JOptionPane.showMessageDialog(this, "Saldo insuficiente.", "Erro", JOptionPane.ERROR_MESSAGE);
                    break;
                case 2:
                    JOptionPane.showMessageDialog(this, "Levantamento realizado com sucesso!");
                    break;
                default:
                    JOptionPane.showMessageDialog(this, "Ocorreu um erro inesperado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Entrada inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao realizar levantamento: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnTransferir.addActionListener(e -> {
        JPanel painel = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField campoOrigem = new JTextField();
        JTextField campoDestino = new JTextField();
        JTextField campoValor = new JTextField();

        painel.add(new JLabel("Conta de Origem:"));
        painel.add(campoOrigem);
        painel.add(new JLabel("Conta de Destino:"));
        painel.add(campoDestino);
        painel.add(new JLabel("Valor a Transferir:"));
        painel.add(campoValor);

        int resultado = JOptionPane.showConfirmDialog(
            this, painel, "Transferir Fundos", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );

        if (resultado == JOptionPane.OK_OPTION) {
            try {
                int origem = Integer.parseInt(campoOrigem.getText().trim());
                int destino = Integer.parseInt(campoDestino.getText().trim());
                double valor = Double.parseDouble(campoValor.getText().trim());

                boolean sucesso = contaService.transferir(origem, destino, valor);
                if (sucesso) {
                    JOptionPane.showMessageDialog(this, "Transferência realizada com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, "Transferência não realizada. Verifique os dados.", "Erro", JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Dados numéricos inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro na transferência: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    btnConsultar.addActionListener(e -> {
        String input = JOptionPane.showInputDialog(this, "Digite o número da conta para consultar:", "Consultar Conta", JOptionPane.QUESTION_MESSAGE);

        if (input == null || input.trim().isEmpty()) {
            return; // Cancelado
        }

        try {
            int numeroConta = Integer.parseInt(input.trim());
            String detalhes = contaService.consultarContaSwing(numeroConta);
            JOptionPane.showMessageDialog(this, detalhes, "Detalhes da Conta", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Número inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao consultar a conta: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnListarView.addActionListener(e -> {
        new JanelaListarViewContas(contaService).setVisible(true);
    });

    btnVoltar.addActionListener(e -> {
        dispose();
        janelaPrincipal.setVisible(true);
    });
}

private void abrirPainelCriarConta() {
        JPanel painel = new JPanel(new GridLayout(8, 2, 10, 10));

        JTextField campoTitular = new JTextField();
        JTextField campoNumero = new JTextField();
        JTextField campoSaldo = new JTextField();
        JTextField campoLimite = new JTextField();
        JTextField campoTaxa = new JTextField();

        JComboBox<TipoConta> comboTipoConta = new JComboBox<>(TipoConta.values());

        comboTipoConta.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                for (Component c : painel.getComponents()) {
                    if (c instanceof JLabel) {
                        String texto = ((JLabel) c).getText();
                        if ("Limite:".equals(texto) || "Taxa:".equals(texto)) {
                            painel.remove(c);
                        }
                    }
                }
                painel.remove(campoLimite);
                painel.remove(campoTaxa);

                TipoConta tipoSelecionado = (TipoConta) comboTipoConta.getSelectedItem();

                if (tipoSelecionado == TipoConta.Ordem) {
                    painel.add(new JLabel("Limite:"));
                    painel.add(campoLimite);
                } else if (tipoSelecionado == TipoConta.Poupanca) {
                    painel.add(new JLabel("Taxa:"));
                    painel.add(campoTaxa);
                }

                painel.revalidate();
                painel.repaint();
            }
        });

        painel.add(new JLabel("Nome do Titular:"));
        painel.add(campoTitular);
        painel.add(new JLabel("Número da Conta:"));
        painel.add(campoNumero);
        painel.add(new JLabel("Saldo Inicial:"));
        painel.add(campoSaldo);
        painel.add(new JLabel("Tipo de Conta:"));
        painel.add(comboTipoConta);

        TipoConta tipoInicial = (TipoConta) comboTipoConta.getSelectedItem();
        if (tipoInicial == TipoConta.Ordem) {
            painel.add(new JLabel("Limite:"));
            painel.add(campoLimite);
        } else if (tipoInicial == TipoConta.Poupanca) {
            painel.add(new JLabel("Taxa:"));
            painel.add(campoTaxa);
        }

        int resultado = JOptionPane.showConfirmDialog(this, painel, "Criar Nova Conta", JOptionPane.OK_CANCEL_OPTION);

        if (resultado == JOptionPane.OK_OPTION) {
            String titular = campoTitular.getText().trim();
            String numeroTexto = campoNumero.getText().trim();
            String saldoTexto = campoSaldo.getText().trim();
            TipoConta tipoConta = (TipoConta) comboTipoConta.getSelectedItem();

            try {
                int numero = Integer.parseInt(numeroTexto);
                double saldo = Double.parseDouble(saldoTexto);

                // Valores adicionais com base no tipo
                double limite = 0.0;
                double taxa = 0.0;

                if (tipoConta == TipoConta.Ordem) {
                    limite = Double.parseDouble(campoLimite.getText().trim());
                } else if (tipoConta == TipoConta.Poupanca) {
                    taxa = Double.parseDouble(campoTaxa.getText().trim());
                }

             // Obter o ID real do utilizador da sessão
                int idUtilizador = Sessao.idUtilizador;

                // Validação local com objeto (opcional)
                Contabancaria conta = new Contabancaria(titular, numero, saldo, tipoConta);

                // Gravar na base de dados
                contaService.criarContaNoBanco(numero, saldo, tipoConta.toString(), limite, taxa, idUtilizador, titular);

                JOptionPane.showMessageDialog(this, "✅ Conta criada com sucesso na Base Dados BVV!");

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Número ou saldo inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
            } catch (DadosInvalidosException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao criar conta: " + e.getMessage(), "Erro de Base de Dados", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
