package contabancaria;

public class ContaPoupanca extends Contabancaria {
    private double taxaJuros;

    // Códigos de cor ANSI
    private static final String RESET = "\u001B[0m";
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String AZUL = "\u001B[34m";
    private static final String AMARELO = "\u001B[33m";

    public ContaPoupanca(String titular, int numConta, double saldo, TipoConta tipoConta, double taxaJuros) throws DadosInvalidosException {
        super(titular, numConta, saldo, tipoConta);

        if (taxaJuros < 0) {
            System.out.println(VERMELHO + "❌ Taxa de juros inválida!" + RESET);
        } else {
            this.taxaJuros = taxaJuros;
        }
    }

    @Override
    public void depositar(double valor) {
        if (valor > 0) {
            double juros = valor * taxaJuros;
            double novoSaldo = getSaldo() + valor + juros;
            setSaldo(novoSaldo);

            System.out.printf(VERDE + "💵 Depósito de %.2f€ mais juros de %.2f€ (%.0f%%). Novo saldo: %.2f€\n" + RESET,
                    valor, juros, taxaJuros * 100, novoSaldo);
        } else {
            System.out.println(VERMELHO + "❌ Depósito inválido! O valor deve ser positivo." + RESET);
        }
    }
    
    public void depositarSemJuros(double valor) {
        if (valor > 0) {
            double novoSaldo = getSaldo() + valor;
            setSaldo(novoSaldo);
            System.out.printf(VERDE + "🏦 Transferência recebida: %.2f€. Novo saldo: %.2f€\n" + RESET, valor, novoSaldo);
        } else {
            System.out.println(VERMELHO + "✘ Valor inválido para transferência." + RESET);
        }
    }

    @Override
    public boolean levantar(double valor) {
        if (valor > 0 && valor <= getSaldo()) {
            setSaldo(getSaldo() - valor);
            System.out.printf(AMARELO + "💸 Levantamento de %.2f€ realizado. Novo saldo: %.2f€\n" + RESET, valor, getSaldo());
            return true;
        } else {
            System.out.printf(VERMELHO + "❌ Levantamento de %.2f€ inválido! Saldo insuficiente (%.2f€).\n" + RESET, valor, getSaldo());
            return false;
        }
    }

    @Override
    public void mostrarDados() {
        System.out.println(AZUL + "Titular: " + RESET + getTitular());
        System.out.println(AZUL + "Número da Conta: " + RESET + getNumConta());
        System.out.println(AZUL + "Saldo: " + RESET + String.format("%.2f€", getSaldo()));
        System.out.println(AZUL + "Tipo de Conta: " + RESET + getTipoConta());
    }
}
