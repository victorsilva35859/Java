package erros;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Ex2 {

    public static void main(String[] args) {

        File file = new File("ficheiro.txt");
        FileReader leitor = null; // Declarado fora do try

        try {
            leitor = new FileReader(file);
            int conteudo = leitor.read();
            System.out.println(conteudo);
        } catch (IOException e) {
            System.out.println("Erro ao ler o ficheiro: " + e.getMessage());
        } finally {
            if (leitor != null) {
                try {
                    leitor.close(); // Fecha o ficheiro com segurança
                } catch (IOException e) {
                    System.out.println("Erro ao fechar o ficheiro: " + e.getMessage());
                }
            }
        }
    }
}


/*
 * 							Estilo moderno (com try-with-resources)
 * A principal vantagem é que os recursos são fechados automaticamente ao sair do bloco try, sem precisar de um bloco finally.


 * 
 * package erros;
 * 
 * import java.io.File; import java.io.FileReader; import java.io.IOException;
 * 
 * public class Ex2 {
 * 
 * public static void main(String[] args) {
 * 
 * File file = new File("ficheiro.txt");
 * 
 * // O FileReader será automaticamente fechado ao sair do bloco try try
 * (FileReader leitor = new FileReader(file)) { int conteudo = leitor.read();
 * System.out.println(conteudo); } catch (IOException e) {
 * System.out.println("Erro ao ler o ficheiro: " + e.getMessage()); } } }
 */