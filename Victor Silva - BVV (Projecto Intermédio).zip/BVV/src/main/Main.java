package main;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import database.DataBaseConnection;
import service.UserService;
import service.ContaService;
import ui.Menu;

public class Main {
    private static final String VERDE = "\u001B[32m";
    private static final String VERMELHO = "\u001B[31m";
    private static final String RESET = "\u001B[0m";
    private static final String BRANCO = "\u001B[37m";

    public static void main(String[] args) {
        // Ligar à base de dados primeiro
        try (DataBaseConnection dbConn = new DataBaseConnection()) {
            Connection conn = dbConn.getConnection();
            System.out.println(BRANCO + "\n✔️ Ligação à base de dados feita com sucesso!\n" + RESET);

            // Instanciar serviços
            UserService userService = new UserService(conn);
            ContaService contaService = new ContaService(conn);
            

            // Fazer login usando a BD
            if (!fazerLogin(userService)) {
                System.out.println(VERMELHO + "🚫 Acesso negado. O programa será encerrado." + RESET);
                return;
            }

            // Instanciar e lançar o menu principal
            Menu menu = new Menu(userService, contaService);
            menu.menuPrincipal();

        } catch (SQLException e) {
            System.err.println(VERMELHO + "Erro na ligação: " + e.getMessage() + RESET);
        }
    }

    // Novo método de login, agora usando UserService
    @SuppressWarnings("resource")
	private static boolean fazerLogin(UserService userService) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("👤 Nome de utilizador: ");
        String user = scanner.nextLine();
        System.out.print("🔑 Senha: ");
        String pass = scanner.nextLine();
        

        boolean sucesso = userService.autenticar(user, pass);
        if (sucesso) {
            System.out.println(VERDE + "✅ Login realizado com sucesso.\n" + RESET);
        } else {
            System.out.println(VERMELHO + "❌ Utilizador ou senha inválidos.\n" + RESET);
        }
        return sucesso;
    }
}
