package Ex3;

public class MinhaRunnable implements Runnable {

    private Contador contador;
    //private String nome;

    public MinhaRunnable(Contador contador, String nome) {
        this.contador = contador;
        //this.nome = nome;
    }

    @Override
    public void run() {
        // Aumenta o valor do contador 50 vezes
        for (int i = 0; i <=50; i++) {
            contador.incrementar(Thread.currentThread().getName());
        }
    }
}
