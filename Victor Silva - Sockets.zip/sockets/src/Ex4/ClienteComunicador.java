package Ex4;

import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ClienteComunicador extends Thread {

    private final Socket socket;

    // Códigos de cor ANSI
    public static final String RESET = "\u001B[0m";
    public static final String VERDE = "\u001B[32m";

    // Construtor que recebe o socket ligado ao cliente
    public ClienteComunicador(Socket socket) {
        this.socket = socket;
    }

    // Método run() é chamado quando damos start() na thread
    @Override
    public void run() {
        try (
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in); // Scanner para ler do servidor
        ) {
            String mensagemRecebida;

            // Comunicação contínua com o cliente até este digitar "sair"
            while ((mensagemRecebida = input.readLine()) != null) {
                if (mensagemRecebida.equalsIgnoreCase("sair")) {
                    break; // termina se o cliente escrever "sair"
                }

                // Captura a hora atual no formato [HH:mm:ss]
                String hora = new SimpleDateFormat("HH:mm:ss").format(new Date());

                // Mostra a mensagem recebida com cor e hora
                System.out.println(VERDE + "[" + hora + "] Servidor recebeu: " + mensagemRecebida + RESET);

                // Escreve uma resposta para o cliente
                System.out.print("Servidor > Escreva a resposta para o cliente: ");
                String resposta = scanner.nextLine();

                // Envia a resposta ao cliente
                output.println("[" + hora + "] Servidor respondeu: " + resposta);
            }

            socket.close(); // Encerra ligação com o cliente
            System.out.println("Servidor > Cliente desconectado.");

        } catch (IOException e) {
            System.out.println("Erro ao comunicar com cliente: " + e.getMessage());
        }
    }
}
