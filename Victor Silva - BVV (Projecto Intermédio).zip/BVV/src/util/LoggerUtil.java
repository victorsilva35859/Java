package util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LoggerUtil {

    private static final String LOG_FILE = "user_access_log.txt";
    private static final String FAILED_LOG_FILE = "user_deny_log.txt";
    private static final String ERROR_LOG_FILE = "error_log.txt";
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void logAcesso(String mensagem) {
        String timestamp = LocalDateTime.now().format(DATE_FORMAT);
        String entradaLog = String.format("%s - %s", timestamp, mensagem);
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            writer.println(entradaLog);
        } catch (IOException e) {
            System.out.println("Erro a registar o acesso: " + e.getMessage());
        }
    }

    public static void logNegado(String mensagem) {
        String timestamp = LocalDateTime.now().format(DATE_FORMAT);
        String entradaLog = String.format("%s - %s", timestamp, mensagem);
        try (PrintWriter writer = new PrintWriter(new FileWriter(FAILED_LOG_FILE, true))) {
            writer.println(entradaLog);
        } catch (IOException e) {
            System.out.println("Erro a registar a falha: " + e.getMessage());
        }
    }

    public static void logErro(String mensagem) {
        String timestamp = LocalDateTime.now().format(DATE_FORMAT);
        String entradaLog = String.format("%s - %s", timestamp, mensagem);
        try (PrintWriter writer = new PrintWriter(new FileWriter(ERROR_LOG_FILE, true))) {
            writer.println(entradaLog);
        } catch (IOException e) {
            System.out.println("Erro a registar o erro: " + e.getMessage());
        }
    }
}
