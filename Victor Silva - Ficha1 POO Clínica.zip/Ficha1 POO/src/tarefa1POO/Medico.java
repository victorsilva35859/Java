package tarefa1POO;


public class Medico extends Pessoa implements Avaliacao {

    private String crm;
    private String especialidade;

    // Cores ANSI
    private static final String RESET = "\u001B[0m";
    private static final String BLUE = "\u001B[34m";
    private static final String CYAN = "\u001B[36m";
    private static final String GREEN = "\u001B[32m";
    private static final String AMARELO = "\u001B[33m";


    public Medico(String nome, int idade, String crm, String especialidade) {
        super(nome, idade);
        this.crm = crm;
        this.especialidade = especialidade;
    }

    @Override
    public void apresentarDados() {
        System.out.println(BLUE + "📘 Nome do Médico: " + RESET + nome);
        System.out.println(CYAN + "🧬 Idade: " + RESET + idade);
        System.out.println(AMARELO + "🆔 CRM: " + RESET + crm);
        System.out.println(AMARELO + "🩺 Especialidade: " + RESET + especialidade);
        System.out.println(GREEN + "✅ Médico ativo no sistema." + RESET);
    }

    @Override
    public void avaliarPaciente(Paciente paciente) {
        double imc = paciente.calcularIMC();
        String classificacao = paciente.interpretarIMC();

        System.out.println(CYAN + "\n🩺 Médico Responsável Avaliação Clínica (IMC): " + RESET + this.nome);
        System.out.println(BLUE + "\n🧾 Avaliação do paciente: " + RESET + paciente.getNome());
        System.out.printf("📏 Altura: %.2fm | ⚖️ Peso: %.2fkg\n", paciente.getAltura(), paciente.getPeso());
        System.out.printf("🧮 IMC: %.2f -> %s%s%s\n", imc, Main.corIMC(imc), classificacao, Main.RESET);
    }

}

