package excecao;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Excecao {

    public static void main(String[] args) {

        File ficheiro = new File("arquivo.txt");
        FileReader leitor = null;

        try {
            leitor = new FileReader(ficheiro);
            int conteudo = leitor.read();
            System.out.println("Conteúdo: " + conteudo);

            int num = 10;
            int den = 0;
            int res = num / den;
            System.out.println("Resultado: " + res);

        } catch (IOException e) {
            System.out.println("Erro de conteúdo: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Erro de cálculo: " + e.getMessage());
        } finally {
            try {
                if (leitor != null) {
                    leitor.close();
                    System.out.println("Ficheiro fechado com sucesso.");
                }
            } catch (IOException e) {
                System.out.println("Erro ao fechar o ficheiro: " + e.getMessage());
            }
        }
    }
}
