package ui.swing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import service.ContaService;

import java.sql.ResultSet;

@SuppressWarnings({ "serial", "unused" })
public class JanelaListarContas extends JFrame {

    public JanelaListarContas(ContaService contaService) {
        super("Lista de Contas");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        String[] colunas = {"ID", "Titular", "Saldo"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(modelo);

        try {
        	ResultSet rs = contaService.obterTodasContas();
            while (rs.next()) {
                int id = rs.getInt("idConta");
                String titular = rs.getString("titular");
                double saldo = rs.getDouble("saldo");
                modelo.addRow(new Object[]{id, titular, saldo});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao listar contas: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        JScrollPane scrollPane = new JScrollPane(tabela);
        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.addActionListener(e -> dispose());

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(btnVoltar, BorderLayout.SOUTH);
    }
}
