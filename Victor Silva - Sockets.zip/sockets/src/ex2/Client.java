package ex2;

import java.io.*;
import java.net.*;
import java.util.Scanner;


public class Client {

    public static void main(String[] args) {
        String host = "localhost";
        int porta = 12345;

        try (Socket socket = new Socket(host, porta)) {
            System.out.println("Ligado ao servidor na porta " + porta);

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true); // auto-flush
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner scanner=new Scanner(System.in);

			/*
			 * String mensagem = "Olá servidor!!!"; output.println(mensagem);
			 * System.out.println("Mensagem enviada: " + mensagem);
			 */

            System.out.println("Escreva a mensagem");
            String mensagem=scanner.nextLine();
            output.println(mensagem);
            
            
            String resposta = input.readLine();
            System.out.println("Resposta do servidor: " + resposta);

        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
