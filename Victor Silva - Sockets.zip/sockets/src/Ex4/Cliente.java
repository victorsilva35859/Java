package Ex4;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Cliente {

    // Códigos de cor ANSI para colorir a consola
    public static final String RESET = "\u001B[0m";
    public static final String AZUL = "\u001B[34m";
    public static final String VERDE = "\u001B[32m";
    public static final String VERMELHO = "\u001B[31m";
    public static final String CIANO = "\u001B[36m";

    public static void main(String[] args) {
        String host = "localhost";
        int porta = 5000;

        try (
            Socket socket = new Socket(host, porta); // Cria socket do cliente
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true); // Canal de saída
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // Canal de entrada
            Scanner scanner = new Scanner(System.in); // Para leitura do teclado
        ) {
            // Pede ao utilizador o nome
            System.out.print(CIANO + "Cliente > Digite o seu nome: " + RESET);
            String nome = scanner.nextLine();

            String mensagem;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

            // Loop contínuo de envio de mensagens
            do {
                System.out.print(CIANO + nome + " > Escreva a sua mensagem: " + RESET);
                mensagem = scanner.nextLine();
                out.println(nome + ":" + mensagem); // Envia nome e mensagem para o servidor

                if (!mensagem.equalsIgnoreCase("sair")) {
                    String resposta = in.readLine(); // Lê resposta do servidor
                    String hora = LocalTime.now().format(formatter);
                    System.out.println(VERDE + "[" + hora + "] Servidor > " + resposta + RESET);
                }

            } while (!mensagem.equalsIgnoreCase("sair"));

            System.out.println(VERMELHO + "Cliente > Ligação terminada." + RESET);

        } catch (IOException e) {
            System.out.println("Cliente > Erro: " + e.getMessage());
        }
    }
}
